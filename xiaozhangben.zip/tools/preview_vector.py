# -*- coding: utf-8 -*-
"""把 ic_launcher_foreground.xml 粗略渲染成 PNG，用来肉眼检查几何是否合理。

只支持本工程用到的子集：M / a（椭圆弧，rot=0）/ Q / Z / 多个子路径。
输出：tools/foreground-preview.png（108*8 px，浅粉背景）
"""
import math
import os
import re
from PIL import Image, ImageDraw

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(BASE, 'app', 'src', 'main', 'res', 'drawable', 'ic_launcher_foreground.xml')
OUT = os.path.join(BASE, 'tools', 'foreground-preview.png')
K = 8  # 放大倍数


def parse_paths(xml):
    out = []
    for m in re.finditer(r'android:fillColor="(#[0-9A-Fa-f]{8})"' + r'\s+android:pathData="([^"]+)"', xml):
        out.append((m.group(1), m.group(2)))
    return out


def tokens(d):
    return re.findall(r'[MaLlQqZzHhVvCc]|-?\d*\.?\d+', d)


def arc_points(x0, y0, rx, ry, large, sweep, dx, dy, steps=48):
    x1, y1 = x0 + dx, y0 + dy
    rx, ry = abs(rx), abs(ry)
    if rx == 0 or ry == 0:
        return [(x1, y1)]
    # 端点参数化 -> 圆心参数化（rot=0）
    mx, my = (x0 - x1) / 2.0, (y0 - y1) / 2.0
    lam = (mx * mx) / (rx * rx) + (my * my) / (ry * ry)
    if lam > 1:
        s = math.sqrt(lam)
        rx, ry = rx * s, ry * s
    num = rx * rx * ry * ry - rx * rx * my * my - ry * ry * mx * mx
    den = rx * rx * my * my + ry * ry * mx * mx
    co = math.sqrt(max(0.0, num / den)) if den else 0.0
    if large == sweep:
        co = -co
    cxp = co * rx * my / ry
    cyp = -co * ry * mx / rx
    cx, cy = cxp + (x0 + x1) / 2.0, cyp + (y0 + y1) / 2.0
    def ang(ux, uy, vx, vy):
        dot = ux * vx + uy * vy
        n = math.sqrt((ux * ux + uy * uy) * (vx * vx + vy * vy)) or 1.0
        a = math.acos(max(-1.0, min(1.0, dot / n)))
        return -a if (ux * vy - uy * vx) < 0 else a
    t1 = ang(1, 0, (mx - cxp) / rx, (my - cyp) / ry)
    dt = ang((mx - cxp) / rx, (my - cyp) / ry, (-mx - cxp) / rx, (-my - cyp) / ry)
    if not sweep and dt > 0:
        dt -= 2 * math.pi
    elif sweep and dt < 0:
        dt += 2 * math.pi
    pts = []
    for i in range(1, steps + 1):
        t = t1 + dt * i / steps
        pts.append((cx + rx * math.cos(t), cy + ry * math.sin(t)))
    return pts


def path_polygons(d):
    """返回每个子路径的点列（close 的路径会回到起点）。"""
    tk = tokens(d)
    i = 0
    polys, cur = [], []
    x = y = 0.0
    start = (0.0, 0.0)
    cmd = None
    while i < len(tk):
        t = tk[i]
        if t in 'MaLlQqZzHhVvCc':
            cmd = t
            i += 1
            if cmd in 'Zz':
                if cur:
                    cur.append(start)
                    polys.append(cur)
                cur = []
                x, y = start
            continue
        if cmd in 'Mm':
            nx, ny = float(tk[i]), float(tk[i + 1])
            i += 2
            if cur:
                cur.append((x, y))
                polys.append(cur)
            cur = [(nx, ny)]
            x, y = nx, ny
            start = (nx, ny)
            cmd = 'L' if cmd == 'M' else 'l'
            continue
        if cmd in 'Aa':
            rx, ry, rot, la, sw, dx, dy = [float(v) for v in tk[i:i + 7]]
            i += 7
            pts = arc_points(x, y, rx, ry, int(la), int(sw), dx, dy)
            cur.extend(pts)
            x, y = x + dx, y + dy
            continue
        if cmd in 'Qq':
            qx, qy, nx, ny = [float(v) for v in tk[i:i + 4]]
            i += 4
            for s in range(1, 25):
                u = s / 24.0
                cur.append((
                    (1 - u) ** 2 * x + 2 * (1 - u) * u * qx + u * u * nx,
                    (1 - u) ** 2 * y + 2 * (1 - u) * u * qy + u * u * ny))
            x, y = nx, ny
            continue
        if cmd in 'Ll':
            nx, ny = float(tk[i]), float(tk[i + 1])
            i += 2
            cur.append((nx, ny))
            x, y = nx, ny
            continue
        raise SystemExit('unsupported token: %r' % (t,))
    if cur:
        polys.append(cur)
    return polys


def rgba(hex8):
    h = hex8.lstrip('#')
    return (int(h[2:4], 16), int(h[4:6], 16), int(h[6:8], 16), int(h[0:2], 16))


def main():
    xml = open(SRC, 'rb').read().decode('utf-8')
    paths = parse_paths(xml)
    print('paths:', len(paths))
    img = Image.new('RGBA', (108 * K, 108 * K), (255, 216, 230, 255))
    for color, d in paths:
        layer = Image.new('RGBA', img.size, (0, 0, 0, 0))
        dl = ImageDraw.Draw(layer)
        for poly in path_polygons(d):
            if len(poly) < 3:
                continue
            dl.polygon([(p[0] * K, p[1] * K) for p in poly], fill=rgba(color))
        img.paste(layer, (0, 0), layer.split()[3])
    img.save(OUT, 'PNG')
    print('written', OUT)


if __name__ == '__main__':
    main()
