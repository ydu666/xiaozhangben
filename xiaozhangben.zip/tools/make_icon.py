# -*- coding: utf-8 -*-
"""生成小账本 App 图标：可爱的粉色小猪脸。

用法： python tools/make_icon.py
输出： app/src/main/res/mipmap-*/ic_launcher.png（+ tools/icon-preview.png）
注意：本机 Pillow 版本很老：没有 rounded_rectangle / alpha_composite / rotate(center) / LANCZOS。
      这里用 paste(mask=alpha)、pieslice、小图旋转后贴图的方式手动实现。
"""
import os
from PIL import Image, ImageDraw

S = 1024
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(BASE, 'app', 'src', 'main', 'res')

SIZES = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
RESIZE_FILTER = getattr(Image, 'ANTIALIAS', Image.BICUBIC)


def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(4))


def over(base, layer):
    """把 layer 按自身 alpha 叠到 base 上（兼容老 Pillow）。"""
    base.paste(layer, (0, 0), layer.split()[3])
    return base


def rounded_mask(size, r):
    m = Image.new('L', (size, size), 0)
    dm = ImageDraw.Draw(m)
    dm.rectangle([r, 0, size - 1 - r, size - 1], fill=255)
    dm.rectangle([0, r, size - 1, size - 1 - r], fill=255)
    dm.pieslice([0, 0, 2 * r, 2 * r], 180, 270, fill=255)
    dm.pieslice([size - 1 - 2 * r, 0, size - 1, 2 * r], 270, 360, fill=255)
    dm.pieslice([0, size - 1 - 2 * r, 2 * r, size - 1], 90, 180, fill=255)
    dm.pieslice([size - 1 - 2 * r, size - 1 - 2 * r, size - 1, size - 1], 0, 90, fill=255)
    return m


def ear(cx, cy, w, h, angle, fill, inner):
    """一只耳朵：椭圆 + 内耳，先在小图里旋转，再贴到整画布。"""
    pad = 24
    lw, lh = w + pad * 2, h + pad * 2
    layer = Image.new('RGBA', (lw, lh), (0, 0, 0, 0))
    dl = ImageDraw.Draw(layer)
    dl.ellipse([pad, pad, pad + w, pad + h], fill=fill)
    iw, ih = int(w * 0.46), int(h * 0.46)
    dl.ellipse([
        pad + (w - iw) // 2, pad + (h - ih) // 2 - int(h * 0.05),
        pad + (w + iw) // 2, pad + (h + ih) // 2 - int(h * 0.05)
    ], fill=inner)
    layer = layer.rotate(angle, resample=Image.BICUBIC)
    out = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    out.paste(layer, (cx - lw // 2, cy - lh // 2), layer.split()[3])
    return out


def build():
    # 1) 粉色渐变 + 圆角背景
    top = (255, 216, 230, 255)
    bot = (255, 128, 170, 255)
    bg = Image.new('RGBA', (S, S))
    dbg = ImageDraw.Draw(bg)
    for y in range(S):
        dbg.line([(0, y), (S, y)], fill=lerp(top, bot, float(y) / (S - 1)))
    mask = rounded_mask(S, int(S * 0.22))
    empty = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    img = Image.composite(bg, empty, mask)

    # 2) 耳朵（先画，被脸盖住下半）
    ear_fill = (255, 150, 182, 255)
    ear_in = (255, 186, 206, 255)
    over(img, ear(336, 292, 186, 232, -28, ear_fill, ear_in))
    over(img, ear(688, 292, 186, 232, 28, ear_fill, ear_in))

    # 3) 脸
    d = ImageDraw.Draw(img)
    d.ellipse([212, 246, 812, 846], fill=(255, 201, 216, 255))

    # 4) 腮红
    blush = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    db = ImageDraw.Draw(blush)
    db.ellipse([240, 592, 384, 696], fill=(255, 116, 158, 120))
    db.ellipse([640, 592, 784, 696], fill=(255, 116, 158, 120))
    over(img, blush)
    d = ImageDraw.Draw(img)

    # 5) 眼睛 + 高光
    eye = (58, 32, 42, 255)
    d.ellipse([390, 452, 464, 526], fill=eye)
    d.ellipse([560, 452, 634, 526], fill=eye)
    d.ellipse([403, 465, 429, 491], fill=(255, 255, 255, 245))
    d.ellipse([573, 465, 599, 491], fill=(255, 255, 255, 245))

    # 6) 猪鼻 + 鼻孔
    d.ellipse([400, 548, 624, 726], fill=(255, 158, 187, 255))
    d.ellipse([448, 600, 492, 664], fill=(206, 88, 126, 255))
    d.ellipse([532, 600, 576, 664], fill=(206, 88, 126, 255))

    # 7) 张嘴笑（下半个椭圆）+ 舌头
    d.pieslice([452, 690, 572, 790], 0, 180, fill=(176, 62, 100, 255))
    d.ellipse([486, 742, 538, 778], fill=(255, 130, 160, 255))

    return img


def main():
    master = build()
    for name, px in SIZES.items():
        out = os.path.join(RES, 'mipmap-' + name)
        if not os.path.isdir(out):
            os.makedirs(out)
        p = os.path.join(out, 'ic_launcher.png')
        master.resize((px, px), RESIZE_FILTER).save(p, 'PNG', optimize=True)
        print('written', p, px)
    prev = os.path.join(BASE, 'tools', 'icon-preview.png')
    master.save(prev, 'PNG')
    print('preview', prev)


if __name__ == '__main__':
    main()
