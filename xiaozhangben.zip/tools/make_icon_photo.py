# -*- coding: utf-8 -*-
"""用 tools/icon-src.jpg 生成 Android 启动图标。

产出：
  app/src/main/res/mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher.png
  app/src/main/res/drawable/ic_launcher_foreground.png   （自适应图标前景）
  tools/icon-preview.png                                  （1024 预览）

注意：本机是 Python 2.7 + 老版 Pillow，
没有 rounded_rectangle / alpha_composite，resize 只能用 Image.ANTIALIAS。
"""
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(HERE, 'icon-src.jpg')
RES = os.path.join(ROOT, 'app', 'src', 'main', 'res')

LEGACY = [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]
CANVAS = 432          # 108dp * 4
INNER = 360           # 画面边长，四周留白与图片白底同色，裁成圆形时看不出来
BG = (255, 255, 255)


def square(im):
    w, h = im.size
    s = min(w, h)
    return im.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))


def rounded_mask(size, r):
    if r <= 0:
        return Image.new('L', (size, size), 255)
    m = Image.new('L', (size, size), 0)
    d = ImageDraw.Draw(m)
    d.rectangle([r, 0, size - 1 - r, size - 1], fill=255)
    d.rectangle([0, r, size - 1, size - 1 - r], fill=255)
    for x, y in ((0, 0), (size - 2 * r, 0), (0, size - 2 * r), (size - 2 * r, size - 2 * r)):
        d.ellipse([x, y, x + 2 * r, y + 2 * r], fill=255)
    return m


def compose():
    """满幅画面 + 圆角遮罩：把源图自带的白角切掉，不留白边"""
    im = square(Image.open(SRC).convert('RGB')).resize((CANVAS, CANVAS), Image.ANTIALIAS)
    art = Image.new('RGBA', (CANVAS, CANVAS), (0, 0, 0, 0))
    art.paste(im.convert('RGBA'), (0, 0), rounded_mask(CANVAS, int(CANVAS * 0.17)))
    return art


def main():
    cover = compose()

    for dpi, size in LEGACY:
        out_dir = os.path.join(RES, 'mipmap-' + dpi)
        if not os.path.isdir(out_dir):
            os.makedirs(out_dir)
        icon = cover.resize((size, size), Image.ANTIALIAS)
        path = os.path.join(out_dir, 'ic_launcher.png')
        icon.save(path)
        print('written', path, size)

    fg_path = os.path.join(RES, 'drawable', 'ic_launcher_foreground.png')
    cover.save(fg_path)
    print('written', fg_path, CANVAS)

    preview = Image.new('RGB', (1024, 1024), BG)
    preview.paste(cover.resize((1024, 1024), Image.ANTIALIAS), (0, 0),
                  cover.resize((1024, 1024), Image.ANTIALIAS))
    preview.save(os.path.join(HERE, 'icon-preview.png'))
    print('preview', os.path.join(HERE, 'icon-preview.png'))


main()
