package com.ezmobile.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * 小账本：一个极简的 WebView 壳。
 * 界面完全由 app/src/main/assets 下的 index.html / app.css / app.js / core.js 提供，
 * 本类只负责三件事：加载离线页面、把账本数据落到应用私有目录、调用系统能力（复制/选文件/导出）。
 */
public class MainActivity extends Activity {

    private static final int REQ_PICK_FILE = 1001;
    private static final String DATA_FILE = "xiaozhangben-data.json";
    private static final long MAX_DATA_BYTES = 64L * 1024 * 1024;

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setDefaultTextEncodingName("UTF-8");
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.setBackgroundColor(0xFFF5F6F8);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                    pendingFileCallback = null;
                }
                pendingFileCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    startActivityForResult(Intent.createChooser(intent, "选择文件"), REQ_PICK_FILE);
                    return true;
                } catch (Exception e) {
                    pendingFileCallback = null;
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_PICK_FILE) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            if (pendingFileCallback != null) {
                pendingFileCallback.onReceiveValue(result);
                pendingFileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    /** 暴露给 JS 的桥：方法名与 assets/app.js 中的调用保持一致。 */
    public class Bridge {

        /** JS 启动时读取账本 JSON，没有则返回空串。 */
        @JavascriptInterface
        public String readData() {
            File f = new File(getFilesDir(), DATA_FILE);
            try {
                if (!f.exists()) return "";
                long len = f.length();
                if (len <= 0 || len > MAX_DATA_BYTES) return "";
                byte[] buf = new byte[(int) len];
                FileInputStream in = new FileInputStream(f);
                try {
                    int off = 0;
                    while (off < buf.length) {
                        int n = in.read(buf, off, buf.length - off);
                        if (n <= 0) break;
                        off += n;
                    }
                } finally {
                    in.close();
                }
                return new String(buf, "UTF-8");
            } catch (Exception e) {
                return "";
            }
        }

        /** 先写临时文件再改名，避免写到一半被杀进程导致账本损坏。 */
        @JavascriptInterface
        public boolean writeData(String json) {
            if (json == null) return false;
            File tmp = new File(getFilesDir(), DATA_FILE + ".tmp");
            File dst = new File(getFilesDir(), DATA_FILE);
            FileOutputStream out = null;
            try {
                out = new FileOutputStream(tmp);
                out.write(json.getBytes("UTF-8"));
                out.flush();
                out.close();
                out = null;
                if (dst.exists() && !dst.delete()) return false;
                return tmp.renameTo(dst);
            } catch (Exception e) {
                return false;
            } finally {
                if (out != null) {
                    try {
                        out.close();
                    } catch (Exception ignore) {
                    }
                }
            }
        }

        /** 复制文本（导出的 CSV 有时很大，走系统剪贴板比弹分享框省事）。 */
        @JavascriptInterface
        public void copyText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("小账本", text == null ? "" : text));
                        Toast.makeText(MainActivity.this, "已复制到剪贴板", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "复制失败", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        /** 把导出内容写到应用外部目录，返回绝对路径供界面提示用户。 */
        @JavascriptInterface
        public String saveFile(String name, String content) {
            try {
                String safe = (name == null || name.trim().length() == 0) ? "xiaozhangben.txt" : name.trim();
                safe = safe.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
                File dir = getExternalFilesDir(null);
                if (dir == null) dir = getFilesDir();
                if (!dir.exists() && !dir.mkdirs()) return "";
                File f = new File(dir, safe);
                FileOutputStream out = new FileOutputStream(f);
                try {
                    out.write(content == null ? new byte[0] : content.getBytes("UTF-8"));
                    out.flush();
                } finally {
                    out.close();
                }
                return f.getAbsolutePath();
            } catch (Exception e) {
                return "";
            }
        }
    }
}
