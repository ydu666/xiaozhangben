/* 小账本 · 纯逻辑层（不依赖 DOM，可在浏览器与 Node 中运行） */
(function (root) {
  'use strict';

  var ACC_TYPES = { cash: '现金', wallet: '钱包', debit: '储蓄卡', credit: '信用卡', invest: '投资' };
  var TYPE_CN = { expense: '支出', income: '收入', transfer: '转账' };

  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function uid(p) {
    return (p || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }
  function toDateStr(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function toTimeStr(d) {
    return toDateStr(d) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  }
  function nowStr() { return toTimeStr(new Date()); }
  function todayStr() { return toDateStr(new Date()); }

  /* 把各种来源的日期文本规范成 'YYYY-MM-DD HH:mm:ss'，失败返回 null */
  function normalizeDateTime(v) {
    if (v === null || v === undefined) return null;
    var t = String(v).trim();
    if (!t) return null;
    t = t.replace(/年/g, '-').replace(/月/g, '-').replace(/日/g, ' ');
    t = t.replace(/时/g, ':').replace(/分/g, ':').replace(/秒/g, ' ');
    t = t.replace(/T/, ' ').replace(/\.\d+/, '');
    t = t.replace(/\s*[zZ]$/, ' ').replace(/\s*[+-]\d{2}:?\d{2}\s*$/, ' ').replace(/\s+/g, ' ').trim();
    var m = t.match(/(\d{4})\s*[-\/.]\s*(\d{1,2})\s*[-\/.]\s*(\d{1,2})(?:\s+(\d{1,2})\s*[:]\s*(\d{1,2})(?:\s*[:]\s*(\d{1,2}))?)?/);
    if (!m) return null;
    var y = +m[1], mo = +m[2], da = +m[3], h = +(m[4] || 0), mi = +(m[5] || 0), se = +(m[6] || 0);
    if (mo < 1 || mo > 12) return null;
    if (da < 1 || da > 31) return null;
    if (h > 23 || mi > 59 || se > 59) return null;
    return y + '-' + pad2(mo) + '-' + pad2(da) + ' ' + pad2(h) + ':' + pad2(mi) + ':' + pad2(se);
  }

  function monthOf(dt) { return String(dt || '').slice(0, 7); }
  function dayOf(dt) { return String(dt || '').slice(0, 10); }

  function shiftMonth(monthStr, delta) {
    var p = String(monthStr).split('-');
    var y = +p[0], m = +p[1] - 1 + delta;
    y += Math.floor(m / 12);
    m = ((m % 12) + 12) % 12;
    return y + '-' + pad2(m + 1);
  }

  function num(v) { var n = Number(v); return isFinite(n) ? n : 0; }

  function fmtMoney(n) {
    var v = num(n);
    return (v < 0 ? '-' : '') + Math.abs(v).toFixed(2);
  }

  function fmtMoneyGroup(n) {
    var v = num(n), neg = v < 0;
    var s = Math.abs(v).toFixed(2).split('.');
    var i = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (neg ? '-' : '') + i + '.' + s[1];
  }

  function parseAmount(v) {
    var s = String(v === null || v === undefined ? '' : v)
      .replace(/[¥￥$,\s]/g, '')
      .replace(/元$/, '');
    if (!s) return null;
    var m = s.match(/-?\d+(?:\.\d+)?/);
    if (!m) return null;
    var n = Number(m[0]);
    return isFinite(n) ? n : null;
  }

  function findById(list, id) {
    if (!list) return null;
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }
  function findByName(list, name, type) {
    if (!list) return null;
    var n = String(name || '').trim();
    for (var i = 0; i < list.length; i++) {
      if (list[i].name === n && (type === undefined || list[i].type === type)) return list[i];
    }
    return null;
  }

  function byTimeDesc(a, b) { return String(b.time).localeCompare(String(a.time)); }
  function byTimeAsc(a, b) { return String(a.time).localeCompare(String(b.time)); }

  /* ---------- 计算 ---------- */

  function accountBalance(state, accountId) {
    var acc = findById(state.accounts, accountId);
    var bal = acc ? num(acc.openingBalance) : 0;
    var txs = state.transactions || [];
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i], amt = num(t.amount);
      if (t.type === 'expense' && t.accountId === accountId) bal -= amt;
      else if (t.type === 'income' && t.accountId === accountId) bal += amt;
      else if (t.type === 'transfer') {
        if (t.accountId === accountId) bal -= amt;
        if (t.toAccountId === accountId) bal += (t.toAmount === null || t.toAmount === undefined) ? amt : num(t.toAmount);
      }
    }
    return Math.round(bal * 100) / 100;
  }

  function monthSummary(state, month) {
    var expense = 0, income = 0, count = 0;
    var txs = state.transactions || [];
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i];
      if (monthOf(t.time) !== month) continue;
      count++;
      if (t.type === 'expense') expense += num(t.amount);
      else if (t.type === 'income') income += num(t.amount);
    }
    return {
      expense: Math.round(expense * 100) / 100,
      income: Math.round(income * 100) / 100,
      net: Math.round((income - expense) * 100) / 100,
      count: count
    };
  }

  function monthTransactions(state, month) {
    return (state.transactions || [])
      .filter(function (t) { return monthOf(t.time) === month; })
      .sort(byTimeDesc);
  }

  function groupByDay(list) {
    var out = [], idx = {};
    for (var i = 0; i < list.length; i++) {
      var d = dayOf(list[i].time);
      if (!idx[d]) { idx[d] = { day: d, items: [], expense: 0, income: 0 }; out.push(idx[d]); }
      idx[d].items.push(list[i]);
      if (list[i].type === 'expense') idx[d].expense += num(list[i].amount);
      else if (list[i].type === 'income') idx[d].income += num(list[i].amount);
    }
    return out;
  }

  function categoryTotals(state, month, type) {
    var map = {}, arr = [];
    var txs = state.transactions || [];
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i];
      if (t.type !== type) continue;
      if (month && monthOf(t.time) !== month) continue;
      var key = t.categoryId || '__none__';
      if (!map[key]) { map[key] = 0; }
      map[key] += num(t.amount);
    }
    Object.keys(map).forEach(function (k) {
      var c = findById(state.categories, k);
      arr.push({ categoryId: k, name: c ? c.name : '未分类', amount: Math.round(map[k] * 100) / 100 });
    });
    arr.sort(function (a, b) { return b.amount - a.amount; });
    return arr;
  }

  function monthlyTrend(state, endMonth, n) {
    var out = [];
    for (var i = n - 1; i >= 0; i--) {
      var m = shiftMonth(endMonth, -i);
      var s = monthSummary(state, m);
      out.push({ month: m, expense: s.expense, income: s.income });
    }
    return out;
  }

  /* ---------- CSV ---------- */

  function csvEscape(v) {
    var s = (v === null || v === undefined) ? '' : String(v);
    if (/[",\r\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function parseCSV(text) {
    var s = String(text === null || text === undefined ? '' : text).replace(/^\uFEFF/, '');
    var rows = [], row = [], cur = '', inQ = false, i = 0;
    while (i < s.length) {
      var ch = s.charAt(i);
      if (inQ) {
        if (ch === '"') {
          if (s.charAt(i + 1) === '"') { cur += '"'; i += 2; continue; }
          inQ = false; i += 1; continue;
        }
        cur += ch; i += 1; continue;
      }
      if (ch === '"') { inQ = true; i += 1; continue; }
      if (ch === ',') { row.push(cur); cur = ''; i += 1; continue; }
      if (ch === '\r') { i += 1; continue; }
      if (ch === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; i += 1; continue; }
      cur += ch; i += 1;
    }
    if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
    return rows.filter(function (r) {
      for (var j = 0; j < r.length; j++) if (String(r[j]).trim() !== '') return true;
      return false;
    });
  }

  var CSV_HEAD = ['交易时间', '交易类型', '金额', '分类', '账户', '备注'];

  function transactionsToCSV(state) {
    var lines = [CSV_HEAD.map(csvEscape).join(',')];
    var txs = (state.transactions || []).slice().sort(byTimeAsc);
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i];
      var c = findById(state.categories, t.categoryId);
      var a = findById(state.accounts, t.accountId);
      var note = t.note || '';
      if (t.type === 'transfer') {
        var to = findById(state.accounts, t.toAccountId);
        note = (note ? note + ' ' : '') + '[' + (a ? a.name : '') + ' → ' + (to ? to.name : '') + ']';
      }
      lines.push([
        t.time, TYPE_CN[t.type] || t.type, fmtMoney(t.type === 'expense' ? -num(t.amount) : num(t.amount)),
        c ? c.name : '', a ? a.name : '', note
      ].map(csvEscape).join(','));
    }
    return '\uFEFF' + lines.join('\r\n') + '\r\n';
  }

  /* 从 CSV 文本导入交易，自动补账户/分类。返回 {created, errors} */
  function importCSV(text, state, opts) {
    opts = opts || {};
    var autoCreate = opts.autoCreate !== false;
    var rows = parseCSV(text);
    var errors = [];
    if (!rows.length) return { created: [], errors: [{ line: 0, reason: '内容为空' }] };

    var headerIdx = -1, col = {};
    for (var i = 0; i < Math.min(rows.length, 12); i++) {
      var cells = rows[i].map(function (c) { return String(c).trim(); });
      var joined = cells.join('');
      var hasTime = /时间|日期/.test(joined);
      var hasAmt = /金额|价格|数目|收入|支出/.test(joined);
      if (hasTime && hasAmt) {
        headerIdx = i;
        for (var k = 0; k < cells.length; k++) {
          var nm = cells[k];
          if (col.time === undefined && /时间|日期/.test(nm)) col.time = k;
          else if (col.type === undefined && /类型|收支/.test(nm)) col.type = k;
          else if (col.amount === undefined && /金额|价格|数目/.test(nm)) col.amount = k;
          else if (col.category === undefined && /分类|类别/.test(nm)) col.category = k;
          else if (col.account === undefined && /账户|帐户|帐号|账号/.test(nm)) col.account = k;
          else if (col.note === undefined && /备注|说明|描述|摘要/.test(nm)) col.note = k;
        }
        break;
      }
    }
    if (headerIdx < 0) {
      return { created: [], errors: [{ line: 0, reason: '找不到表头（需要含“时间/日期”和“金额”两列）' }] };
    }
    if (col.time === undefined || col.amount === undefined) {
      return { created: [], errors: [{ line: headerIdx + 1, reason: '表头缺少“交易时间”或“金额”列' }] };
    }

    var created = [];
    for (var r = headerIdx + 1; r < rows.length; r++) {
      var row = rows[r];
      var lineNo = r + 1;
      var rawTime = row[col.time];
      var time = normalizeDateTime(rawTime);
      if (!time) { errors.push({ line: lineNo, reason: '日期无法识别：' + String(rawTime === undefined ? '' : rawTime).slice(0, 20) }); continue; }

      var amt = parseAmount(row[col.amount]);
      if (amt === null) { errors.push({ line: lineNo, reason: '金额无法识别' }); continue; }
      if (amt === 0) { errors.push({ line: lineNo, reason: '金额为 0' }); continue; }

      var typeTxt = col.type !== undefined ? String(row[col.type] || '').trim() : '';
      var type;
      if (/转账|转帐/.test(typeTxt)) type = 'transfer';
      else if (/收入|收/.test(typeTxt)) type = 'income';
      else if (/支出|支/.test(typeTxt)) type = 'expense';
      else type = amt < 0 ? 'expense' : 'income';

      if (type === 'transfer') {
        errors.push({ line: lineNo, reason: '暂不支持导入“转账”，请手动补录' });
        continue;
      }

      var amount = Math.abs(amt);

      var catName = col.category !== undefined ? String(row[col.category] || '').trim() : '';
      var cat = null;
      if (catName) {
        cat = findByName(state.categories, catName, type);
        if (!cat && autoCreate) {
          cat = { id: uid('cat'), name: catName, type: type };
          state.categories.push(cat);
        }
      }
      if (!cat) cat = findByName(state.categories, type === 'income' ? '其他收入' : '其他', type);

      var accName = col.account !== undefined ? String(row[col.account] || '').trim() : '';
      var acc = null;
      if (accName) {
        acc = findByName(state.accounts, accName);
        if (!acc && autoCreate) {
          acc = { id: uid('acc'), name: accName, type: 'wallet', openingBalance: 0 };
          state.accounts.push(acc);
        }
      }
      if (!acc) acc = findById(state.accounts, state.settings && state.settings.defaultAccountId) || state.accounts[0];

      var note = col.note !== undefined ? String(row[col.note] || '').trim() : '';

      var tx = {
        id: uid('tx'),
        type: type,
        time: time,
        amount: amount,
        categoryId: cat ? cat.id : null,
        accountId: acc ? acc.id : null,
        toAccountId: null,
        toAmount: null,
        note: note,
        createdAt: nowStr()
      };
      state.transactions.push(tx);
      created.push(tx);
    }
    return { created: created, errors: errors };
  }

  function defaultState() {
    var cats = [];
    ['餐饮', '交通', '购物', '居住', '娱乐', '医疗', '学习', '人情', '其他'].forEach(function (n) {
      cats.push({ id: uid('cat'), name: n, type: 'expense' });
    });
    ['工资', '奖金', '理财', '红包', '其他收入'].forEach(function (n) {
      cats.push({ id: uid('cat'), name: n, type: 'income' });
    });
    return {
      app: 'xiaozhangben',
      version: 1,
      createdAt: nowStr(),
      accounts: [
        { id: uid('acc'), name: '现金', type: 'cash', openingBalance: 0 },
        { id: uid('acc'), name: '微信零钱', type: 'wallet', openingBalance: 0 },
        { id: uid('acc'), name: '支付宝', type: 'wallet', openingBalance: 0 },
        { id: uid('acc'), name: '银行卡', type: 'debit', openingBalance: 0 }
      ],
      categories: cats,
      transactions: [],
      settings: { defaultAccountId: null }
    };
  }

  function normalizeState(s) {
    if (!s || typeof s !== 'object') return defaultState();
    var d = defaultState();
    s.accounts = Array.isArray(s.accounts) ? s.accounts : d.accounts;
    s.categories = Array.isArray(s.categories) ? s.categories : d.categories;
    s.transactions = Array.isArray(s.transactions) ? s.transactions : [];
    s.settings = s.settings || {};
    if (!s.settings.defaultAccountId && s.accounts.length) s.settings.defaultAccountId = s.accounts[0].id;
    s.transactions.forEach(function (t) {
      t.amount = num(t.amount);
      t.type = t.type || 'expense';
      if (!t.time) t.time = nowStr();
    });
    return s;
  }

  var Core = {
    ACC_TYPES: ACC_TYPES,
    TYPE_CN: TYPE_CN,
    CSV_HEAD: CSV_HEAD,
    pad2: pad2,
    uid: uid,
    nowStr: nowStr,
    todayStr: todayStr,
    toTimeStr: toTimeStr,
    normalizeDateTime: normalizeDateTime,
    monthOf: monthOf,
    dayOf: dayOf,
    shiftMonth: shiftMonth,
    fmtMoney: fmtMoney,
    fmtMoneyGroup: fmtMoneyGroup,
    parseAmount: parseAmount,
    num: num,
    findById: findById,
    findByName: findByName,
    byTimeDesc: byTimeDesc,
    byTimeAsc: byTimeAsc,
    accountBalance: accountBalance,
    monthSummary: monthSummary,
    monthTransactions: monthTransactions,
    groupByDay: groupByDay,
    categoryTotals: categoryTotals,
    monthlyTrend: monthlyTrend,
    csvEscape: csvEscape,
    parseCSV: parseCSV,
    transactionsToCSV: transactionsToCSV,
    importCSV: importCSV,
    defaultState: defaultState,
    normalizeState: normalizeState
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Core;
  root.Core = Core;
}(typeof window !== 'undefined' ? window : globalThis));
