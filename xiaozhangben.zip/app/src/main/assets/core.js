/* 小账本 · 纯逻辑层（不依赖 DOM，可在浏览器与 Node 中运行） */
(function (root) {
  'use strict';

  var ACC_TYPES = { cash: '现金', wallet: '钱包', debit: '储蓄卡', credit: '信用卡', invest: '投资' };
  var TYPE_CN = { expense: '支出', income: '收入', transfer: '转账' };

  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function uid(p) {
    return (p || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }
  function toDateStr(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function toTimeStr(d) {
    return toDateStr(d) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  }
  function nowStr() { return toTimeStr(new Date()); }
  function todayStr() { return toDateStr(new Date()); }

  /* 把各种来源的日期文本规范成 'YYYY-MM-DD HH:mm:ss'，失败返回 null */
  function normalizeDateTime(v) {
    if (v === null || v === undefined) return null;
    var t = String(v).trim();
    if (!t) return null;
    t = t.replace(/年/g, '-').replace(/月/g, '-').replace(/日/g, ' ');
    t = t.replace(/时/g, ':').replace(/分/g, ':').replace(/秒/g, ' ');
    t = t.replace(/T/, ' ').replace(/\.\d+/, '');
    t = t.replace(/\s*[zZ]$/, ' ').replace(/\s*[+-]\d{2}:?\d{2}\s*$/, ' ').replace(/\s+/g, ' ').trim();
    var m = t.match(/(\d{4})\s*[-\/.]\s*(\d{1,2})\s*[-\/.]\s*(\d{1,2})(?:\s+(\d{1,2})\s*[:]\s*(\d{1,2})(?:\s*[:]\s*(\d{1,2}))?)?/);
    if (!m) return null;
    var y = +m[1], mo = +m[2], da = +m[3], h = +(m[4] || 0), mi = +(m[5] || 0), se = +(m[6] || 0);
    if (mo < 1 || mo > 12) return null;
    if (da < 1 || da > 31) return null;
    if (h > 23 || mi > 59 || se > 59) return null;
    return y + '-' + pad2(mo) + '-' + pad2(da) + ' ' + pad2(h) + ':' + pad2(mi) + ':' + pad2(se);
  }

  function monthOf(dt) { return String(dt || '').slice(0, 7); }
  function dayOf(dt) { return String(dt || '').slice(0, 10); }

  function shiftMonth(monthStr, delta) {
    var p = String(monthStr).split('-');
    var y = +p[0], m = +p[1] - 1 + delta;
    y += Math.floor(m / 12);
    m = ((m % 12) + 12) % 12;
    return y + '-' + pad2(m + 1);
  }

  function num(v) { var n = Number(v); return isFinite(n) ? n : 0; }
  function round2(n) { return Math.round(num(n) * 100) / 100; }

  function yearOf(dt) { return String(dt || '').slice(0, 4); }

  function daysInMonth(monthStr) {
    var p = String(monthStr).split('-');
    return new Date(+p[0], +p[1], 0).getDate();
  }

  function daysInYear(yearStr) {
    var y = +String(yearStr).slice(0, 4);
    return ((y % 4 === 0 && y % 100 !== 0) || y % 400 === 0) ? 366 : 365;
  }

  function fmtMoney(n) {
    var v = num(n);
    return (v < 0 ? '-' : '') + Math.abs(v).toFixed(2);
  }

  function fmtMoneyGroup(n) {
    var v = num(n), neg = v < 0;
    var s = Math.abs(v).toFixed(2).split('.');
    var i = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (neg ? '-' : '') + i + '.' + s[1];
  }

  function parseAmount(v) {
    var s = String(v === null || v === undefined ? '' : v)
      .replace(/[¥￥$,\s]/g, '')
      .replace(/元$/, '');
    if (!s) return null;
    var m = s.match(/-?\d+(?:\.\d+)?/);
    if (!m) return null;
    var n = Number(m[0]);
    return isFinite(n) ? n : null;
  }

  function findById(list, id) {
    if (!list) return null;
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }
  function findByName(list, name, type) {
    if (!list) return null;
    var n = String(name || '').trim();
    for (var i = 0; i < list.length; i++) {
      if (list[i].name === n && (type === undefined || list[i].type === type)) return list[i];
    }
    return null;
  }

  function byTimeDesc(a, b) { return String(b.time).localeCompare(String(a.time)); }
  function byTimeAsc(a, b) { return String(a.time).localeCompare(String(b.time)); }

  /* ---------- 计算 ---------- */

  function accountBalance(state, accountId) {
    var acc = findById(state.accounts, accountId);
    var bal = acc ? num(acc.openingBalance) : 0;
    var txs = state.transactions || [];
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i], amt = num(t.amount);
      if (t.type === 'expense' && t.accountId === accountId) bal -= amt;
      else if (t.type === 'income' && t.accountId === accountId) bal += amt;
      else if (t.type === 'transfer') {
        if (t.accountId === accountId) bal -= amt;
        if (t.toAccountId === accountId) bal += (t.toAmount === null || t.toAmount === undefined) ? amt : num(t.toAmount);
      }
    }
    return Math.round(bal * 100) / 100;
  }

  function monthSummary(state, month) {
    var expense = 0, income = 0, count = 0;
    var txs = state.transactions || [];
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i];
      if (monthOf(t.time) !== month) continue;
      count++;
      if (t.type === 'expense') expense += num(t.amount);
      else if (t.type === 'income') income += num(t.amount);
    }
    return {
      expense: Math.round(expense * 100) / 100,
      income: Math.round(income * 100) / 100,
      net: Math.round((income - expense) * 100) / 100,
      count: count
    };
  }

  function monthTransactions(state, month) {
    return (state.transactions || [])
      .filter(function (t) { return monthOf(t.time) === month; })
      .sort(byTimeDesc);
  }

  function groupByDay(list) {
    var out = [], idx = {};
    for (var i = 0; i < list.length; i++) {
      var d = dayOf(list[i].time);
      if (!idx[d]) { idx[d] = { day: d, items: [], expense: 0, income: 0 }; out.push(idx[d]); }
      idx[d].items.push(list[i]);
      if (list[i].type === 'expense') idx[d].expense += num(list[i].amount);
      else if (list[i].type === 'income') idx[d].income += num(list[i].amount);
    }
    return out;
  }

  function categoryTotals(state, month, type) {
    var map = {}, arr = [];
    var txs = state.transactions || [];
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i];
      if (t.type !== type) continue;
      if (month && monthOf(t.time) !== month) continue;
      var key = t.categoryId || '__none__';
      if (!map[key]) { map[key] = 0; }
      map[key] += num(t.amount);
    }
    Object.keys(map).forEach(function (k) {
      var c = findById(state.categories, k);
      arr.push({ categoryId: k, name: c ? c.name : '未分类', amount: Math.round(map[k] * 100) / 100 });
    });
    arr.sort(function (a, b) { return b.amount - a.amount; });
    return arr;
  }

  function monthlyTrend(state, endMonth, n) {
    var out = [];
    for (var i = n - 1; i >= 0; i--) {
      var m = shiftMonth(endMonth, -i);
      var s = monthSummary(state, m);
      out.push({ month: m, expense: s.expense, income: s.income });
    }
    return out;
  }

  /* 区间汇总：fromMonth/toMonth 形如 'YYYY-MM'，含两端 */
  function rangeSummary(state, fromMonth, toMonth) {
    var from = fromMonth || '0000-00';
    var to = toMonth || '9999-99';
    var expense = 0, income = 0, count = 0;
    var activeDays = {};
    var maxAmount = 0, maxNote = '', maxCategoryId = null;
    var txs = state.transactions || [];
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i];
      var m = monthOf(t.time);
      if (m < from || m > to) continue;
      count++;
      activeDays[dayOf(t.time)] = 1;
      if (t.type === 'expense') {
        var a = num(t.amount);
        expense += a;
        if (a > maxAmount) { maxAmount = a; maxNote = t.note || ''; maxCategoryId = t.categoryId || null; }
      } else if (t.type === 'income') {
        income += num(t.amount);
      }
    }
    var maxCat = findById(state.categories, maxCategoryId);
    return {
      from: from, to: to,
      expense: round2(expense),
      income: round2(income),
      net: round2(income - expense),
      count: count,
      activeDays: Object.keys(activeDays).length,
      maxAmount: round2(maxAmount),
      maxNote: maxNote,
      maxCategory: maxCat ? maxCat.name : ''
    };
  }

  /* 总览：mode = 'month' | 'year'，key = 'YYYY-MM' | 'YYYY' */
  function overview(state, mode, key) {
    var isYear = mode === 'year';
    var from, to, calendarDays;
    if (isYear) {
      var y = String(key).slice(0, 4);
      from = y + '-01'; to = y + '-12';
      calendarDays = daysInYear(y);
    } else {
      from = to = String(key);
      calendarDays = daysInMonth(key);
    }
    var s = rangeSummary(state, from, to);
    var cats = categoryTotalsBetween(state, from, to, 'expense');
    return {
      mode: isYear ? 'year' : 'month',
      key: key,
      from: from, to: to,
      income: s.income, expense: s.expense, net: s.net,
      count: s.count, activeDays: s.activeDays, calendarDays: calendarDays,
      avgPerDay: calendarDays ? round2(s.expense / calendarDays) : 0,
      maxAmount: s.maxAmount, maxNote: s.maxNote, maxCategory: s.maxCategory,
      categoryCount: cats.length
    };
  }

  /* 某月每天： [{key:'01',label:'1',expense,income}] */
  function daySeries(state, month) {
    var n = daysInMonth(month), out = [], i;
    for (i = 1; i <= n; i++) out.push({ key: pad2(i), label: String(i), expense: 0, income: 0 });
    var txs = state.transactions || [];
    for (i = 0; i < txs.length; i++) {
      var t = txs[i];
      if (monthOf(t.time) !== month) continue;
      var d = +dayOf(t.time).slice(8, 10);
      if (d < 1 || d > n) continue;
      if (t.type === 'expense') out[d - 1].expense += num(t.amount);
      else if (t.type === 'income') out[d - 1].income += num(t.amount);
    }
    out.forEach(function (x) { x.expense = round2(x.expense); x.income = round2(x.income); });
    return out;
  }

  /* 某年 12 个月： [{key:'2024-01',label:'1月',expense,income}] */
  function yearSeries(state, year) {
    var y = String(year).slice(0, 4), out = [];
    for (var m = 1; m <= 12; m++) {
      var key = y + '-' + pad2(m);
      var s = monthSummary(state, key);
      out.push({ key: key, label: m + '月', expense: s.expense, income: s.income });
    }
    return out;
  }

  function categoryTotalsBetween(state, fromMonth, toMonth, type) {
    var from = fromMonth || '0000-00';
    var to = toMonth || '9999-99';
    var map = {}, arr = [];
    var txs = state.transactions || [];
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i];
      if (t.type !== type) continue;
      var m = monthOf(t.time);
      if (m < from || m > to) continue;
      var key = t.categoryId || '__none__';
      if (!map[key]) map[key] = 0;
      map[key] += num(t.amount);
    }
    Object.keys(map).forEach(function (k) {
      var c = findById(state.categories, k);
      arr.push({ categoryId: k, name: c ? c.name : '未分类', amount: round2(map[k]) });
    });
    arr.sort(function (a, b) { return b.amount - a.amount; });
    return arr;
  }

  /* ---------- 预算 ---------- */

  function budgetsOf(state) {
    return (state.settings && state.settings.budgets) || {};
  }

  function budgetOf(state, month) {
    var v = budgetsOf(state)[month];
    if (v === null || v === undefined || v === '') return null;
    var n = num(v);
    return n > 0 ? round2(n) : null;
  }

  function setBudget(state, month, amount) {
    state.settings = state.settings || {};
    state.settings.budgets = state.settings.budgets || {};
    if (amount === null || amount === undefined || amount === '' || num(amount) <= 0) {
      delete state.settings.budgets[month];
      return null;
    }
    state.settings.budgets[month] = round2(amount);
    return state.settings.budgets[month];
  }

  function budgetStatus(state, month) {
    var budget = budgetOf(state, month);
    var spent = monthSummary(state, month).expense;
    if (budget === null) {
      return { has: false, budget: null, spent: spent, left: null, percent: 0, ratio: 0, over: false };
    }
    var left = round2(budget - spent);
    var pct = budget > 0 ? (spent / budget) * 100 : 0;
    return {
      has: true,
      budget: budget,
      spent: spent,
      left: left,
      percent: Math.round(pct * 10) / 10,
      ratio: Math.max(0, Math.min(1, spent / budget)),
      over: spent > budget
    };
  }

  /* ---------- 大件（奢侈品/贵重物品） ---------- */

  var BIG_STATUS = { want: '想买', bought: '已买' };
  var BIG_CATS = ['手表', '包袋', '珠宝', '数码', '家电', '汽车', '其他'];

  function bigItemStats(items) {
    var list = items || [];
    var out = {
      count: list.length, wantCount: 0, boughtCount: 0,
      wantTotal: 0, boughtTotal: 0, max: 0, maxName: ''
    };
    for (var i = 0; i < list.length; i++) {
      var it = list[i];
      var p = num(it.price);
      if (it.status === 'bought') { out.boughtCount++; out.boughtTotal += p; }
      else { out.wantCount++; out.wantTotal += p; }
      if (p > out.max) { out.max = p; out.maxName = it.name || ''; }
    }
    out.wantTotal = round2(out.wantTotal);
    out.boughtTotal = round2(out.boughtTotal);
    out.max = round2(out.max);
    return out;
  }

  /* ---------- CSV ---------- */

  function csvEscape(v) {
    var s = (v === null || v === undefined) ? '' : String(v);
    if (/[",\r\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function parseCSV(text) {
    var s = String(text === null || text === undefined ? '' : text).replace(/^\uFEFF/, '');
    var rows = [], row = [], cur = '', inQ = false, i = 0;
    while (i < s.length) {
      var ch = s.charAt(i);
      if (inQ) {
        if (ch === '"') {
          if (s.charAt(i + 1) === '"') { cur += '"'; i += 2; continue; }
          inQ = false; i += 1; continue;
        }
        cur += ch; i += 1; continue;
      }
      if (ch === '"') { inQ = true; i += 1; continue; }
      if (ch === ',') { row.push(cur); cur = ''; i += 1; continue; }
      if (ch === '\r') { i += 1; continue; }
      if (ch === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; i += 1; continue; }
      cur += ch; i += 1;
    }
    if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
    return rows.filter(function (r) {
      for (var j = 0; j < r.length; j++) if (String(r[j]).trim() !== '') return true;
      return false;
    });
  }

  var CSV_HEAD = ['交易时间', '交易类型', '金额', '分类', '账户', '备注'];

  function transactionsToCSV(state) {
    var lines = [CSV_HEAD.map(csvEscape).join(',')];
    var txs = (state.transactions || []).slice().sort(byTimeAsc);
    for (var i = 0; i < txs.length; i++) {
      var t = txs[i];
      var c = findById(state.categories, t.categoryId);
      var a = findById(state.accounts, t.accountId);
      var note = t.note || '';
      if (t.type === 'transfer') {
        var to = findById(state.accounts, t.toAccountId);
        note = (note ? note + ' ' : '') + '[' + (a ? a.name : '') + ' → ' + (to ? to.name : '') + ']';
      }
      lines.push([
        t.time, TYPE_CN[t.type] || t.type, fmtMoney(t.type === 'expense' ? -num(t.amount) : num(t.amount)),
        c ? c.name : '', a ? a.name : '', note
      ].map(csvEscape).join(','));
    }
    return '\uFEFF' + lines.join('\r\n') + '\r\n';
  }

  /* 从 CSV 文本导入交易，自动补账户/分类。返回 {created, errors} */
  function importCSV(text, state, opts) {
    opts = opts || {};
    var autoCreate = opts.autoCreate !== false;
    var rows = parseCSV(text);
    var errors = [];
    if (!rows.length) return { created: [], errors: [{ line: 0, reason: '内容为空' }] };

    var headerIdx = -1, col = {};
    for (var i = 0; i < Math.min(rows.length, 12); i++) {
      var cells = rows[i].map(function (c) { return String(c).trim(); });
      var joined = cells.join('');
      var hasTime = /时间|日期/.test(joined);
      var hasAmt = /金额|价格|数目|收入|支出/.test(joined);
      if (hasTime && hasAmt) {
        headerIdx = i;
        for (var k = 0; k < cells.length; k++) {
          var nm = cells[k];
          if (col.time === undefined && /时间|日期/.test(nm)) col.time = k;
          else if (col.type === undefined && /类型|收支/.test(nm)) col.type = k;
          else if (col.amount === undefined && /金额|价格|数目/.test(nm)) col.amount = k;
          else if (col.category === undefined && /分类|类别/.test(nm)) col.category = k;
          else if (col.account === undefined && /账户|帐户|帐号|账号/.test(nm)) col.account = k;
          else if (col.note === undefined && /备注|说明|描述|摘要/.test(nm)) col.note = k;
        }
        break;
      }
    }
    if (headerIdx < 0) {
      return { created: [], errors: [{ line: 0, reason: '找不到表头（需要含“时间/日期”和“金额”两列）' }] };
    }
    if (col.time === undefined || col.amount === undefined) {
      return { created: [], errors: [{ line: headerIdx + 1, reason: '表头缺少“交易时间”或“金额”列' }] };
    }

    var created = [];
    for (var r = headerIdx + 1; r < rows.length; r++) {
      var row = rows[r];
      var lineNo = r + 1;
      var rawTime = row[col.time];
      var time = normalizeDateTime(rawTime);
      if (!time) { errors.push({ line: lineNo, reason: '日期无法识别：' + String(rawTime === undefined ? '' : rawTime).slice(0, 20) }); continue; }

      var amt = parseAmount(row[col.amount]);
      if (amt === null) { errors.push({ line: lineNo, reason: '金额无法识别' }); continue; }
      if (amt === 0) { errors.push({ line: lineNo, reason: '金额为 0' }); continue; }

      var typeTxt = col.type !== undefined ? String(row[col.type] || '').trim() : '';
      var type;
      if (/转账|转帐/.test(typeTxt)) type = 'transfer';
      else if (/收入|收/.test(typeTxt)) type = 'income';
      else if (/支出|支/.test(typeTxt)) type = 'expense';
      else type = amt < 0 ? 'expense' : 'income';

      if (type === 'transfer') {
        errors.push({ line: lineNo, reason: '暂不支持导入“转账”，请手动补录' });
        continue;
      }

      var amount = Math.abs(amt);

      var catName = col.category !== undefined ? String(row[col.category] || '').trim() : '';
      var cat = null;
      if (catName) {
        cat = findByName(state.categories, catName, type);
        if (!cat && autoCreate) {
          cat = { id: uid('cat'), name: catName, type: type };
          state.categories.push(cat);
        }
      }
      if (!cat) cat = findByName(state.categories, type === 'income' ? '其他收入' : '其他', type);

      var accName = col.account !== undefined ? String(row[col.account] || '').trim() : '';
      var acc = null;
      if (accName) {
        acc = findByName(state.accounts, accName);
        if (!acc && autoCreate) {
          acc = { id: uid('acc'), name: accName, type: 'wallet', openingBalance: 0 };
          state.accounts.push(acc);
        }
      }
      if (!acc) acc = findById(state.accounts, state.settings && state.settings.defaultAccountId) || state.accounts[0];

      var note = col.note !== undefined ? String(row[col.note] || '').trim() : '';

      var tx = {
        id: uid('tx'),
        type: type,
        time: time,
        amount: amount,
        categoryId: cat ? cat.id : null,
        accountId: acc ? acc.id : null,
        toAccountId: null,
        toAmount: null,
        note: note,
        createdAt: nowStr()
      };
      state.transactions.push(tx);
      created.push(tx);
    }
    return { created: created, errors: errors };
  }

  function defaultState() {
    var cats = [];
    ['餐饮', '交通', '购物', '居住', '娱乐', '医疗', '学习', '人情', '其他'].forEach(function (n) {
      cats.push({ id: uid('cat'), name: n, type: 'expense' });
    });
    ['工资', '奖金', '理财', '红包', '其他收入'].forEach(function (n) {
      cats.push({ id: uid('cat'), name: n, type: 'income' });
    });
    return {
      app: 'xiaozhangben',
      version: 1,
      createdAt: nowStr(),
      accounts: [
        { id: uid('acc'), name: '现金', type: 'cash', openingBalance: 0 },
        { id: uid('acc'), name: '微信零钱', type: 'wallet', openingBalance: 0 },
        { id: uid('acc'), name: '支付宝', type: 'wallet', openingBalance: 0 },
        { id: uid('acc'), name: '银行卡', type: 'debit', openingBalance: 0 }
      ],
      categories: cats,
      transactions: [],
      bigItems: [],
      settings: { defaultAccountId: null, budgets: {} }
    };
  }

  function normalizeState(s) {
    if (!s || typeof s !== 'object') return defaultState();
    var d = defaultState();
    s.accounts = Array.isArray(s.accounts) ? s.accounts : d.accounts;
    s.categories = Array.isArray(s.categories) ? s.categories : d.categories;
    s.transactions = Array.isArray(s.transactions) ? s.transactions : [];
    s.settings = s.settings || {};
    if (!s.settings.budgets || typeof s.settings.budgets !== 'object') s.settings.budgets = {};
    Object.keys(s.settings.budgets).forEach(function (k) {
      var v = num(s.settings.budgets[k]);
      if (!(v > 0)) delete s.settings.budgets[k]; else s.settings.budgets[k] = round2(v);
    });
    if (!s.settings.defaultAccountId && s.accounts.length) s.settings.defaultAccountId = s.accounts[0].id;
    s.bigItems = Array.isArray(s.bigItems) ? s.bigItems : [];
    s.bigItems.forEach(function (it) {
      it.price = num(it.price);
      it.status = it.status === 'bought' ? 'bought' : 'want';
      if (!it.date) it.date = todayStr();
      if (!it.cat) it.cat = '其他';
    });
    s.transactions.forEach(function (t) {
      t.amount = num(t.amount);
      t.type = t.type || 'expense';
      if (!t.time) t.time = nowStr();
    });
    return s;
  }

  var Core = {
    ACC_TYPES: ACC_TYPES,
    TYPE_CN: TYPE_CN,
    CSV_HEAD: CSV_HEAD,
    pad2: pad2,
    uid: uid,
    nowStr: nowStr,
    todayStr: todayStr,
    toTimeStr: toTimeStr,
    normalizeDateTime: normalizeDateTime,
    monthOf: monthOf,
    dayOf: dayOf,
    shiftMonth: shiftMonth,
    yearOf: yearOf,
    daysInMonth: daysInMonth,
    daysInYear: daysInYear,
    round2: round2,
    fmtMoney: fmtMoney,
    fmtMoneyGroup: fmtMoneyGroup,
    parseAmount: parseAmount,
    num: num,
    findById: findById,
    findByName: findByName,
    byTimeDesc: byTimeDesc,
    byTimeAsc: byTimeAsc,
    accountBalance: accountBalance,
    monthSummary: monthSummary,
    monthTransactions: monthTransactions,
    groupByDay: groupByDay,
    categoryTotals: categoryTotals,
    categoryTotalsBetween: categoryTotalsBetween,
    monthlyTrend: monthlyTrend,
    rangeSummary: rangeSummary,
    overview: overview,
    daySeries: daySeries,
    yearSeries: yearSeries,
    budgetOf: budgetOf,
    setBudget: setBudget,
    budgetStatus: budgetStatus,
    BIG_STATUS: BIG_STATUS,
    BIG_CATS: BIG_CATS,
    bigItemStats: bigItemStats,
    csvEscape: csvEscape,
    parseCSV: parseCSV,
    transactionsToCSV: transactionsToCSV,
    importCSV: importCSV,
    defaultState: defaultState,
    normalizeState: normalizeState
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Core;
  root.Core = Core;
}(typeof window !== 'undefined' ? window : globalThis));
