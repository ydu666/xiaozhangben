/* 小账本 · 界面层 */
(function () {
  'use strict';

  var C = window.Core;
  var KEY = 'xiaozhangben.v1';
  var Native = window.AndroidBridge || null;
  var APP_VER = '1.1.0';

  var state = null;
  var listMonth = C.monthOf(C.nowStr());
  var currentView = 'list';
  var draft = null;
  var modalOnOk = null;
  var ctx = {};

  var statsMode = 'month';
  var statsMonth = C.monthOf(C.nowStr());
  var statsYear = String(new Date().getFullYear());

  /* ================= 基础工具 ================= */
  function $(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  var toastTimer = null;
  function toast(msg) {
    var el = $('toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.remove('hidden');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.add('hidden'); }, 2400);
  }

  var ICONS = {
    '餐饮': '🍜', '交通': '🚌', '购物': '🛍', '居住': '🏠', '娱乐': '🎮',
    '医疗': '💊', '学习': '📚', '人情': '🎁', '其他': '📦', '其他收入': '💵',
    '工资': '💰', '奖金': '🏆', '理财': '📈', '红包': '🧧'
  };
  function iconFor(name) { return ICONS[name] || '💳'; }

  function daysInMonth(m) {
    var p = String(m).split('-');
    return new Date(+p[0], +p[1], 0).getDate();
  }

  var WD = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  function dayLabel(day) {
    var p = String(day).split('-');
    var d = new Date(+p[0], +p[1] - 1, +p[2]);
    var nowY = new Date().getFullYear();
    var head = (+p[0] === nowY) ? (p[1] + '-' + p[2]) : (p[0] + '-' + p[1] + '-' + p[2]);
    return head + ' ' + (WD[d.getDay()] || '');
  }
  function monthLabel(m) {
    var p = String(m).split('-');
    return p[0] + '年' + (+p[1]) + '月';
  }

  /* ================= 存储 ================= */
  function readRaw() {
    if (Native && typeof Native.readData === 'function') {
      try { var s = Native.readData(); if (s) return s; } catch (e) { }
    }
    try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; }
  }

  function writeRaw(json) {
    var ok = false;
    if (Native && typeof Native.writeData === 'function') {
      try { ok = !!Native.writeData(json); } catch (e) { }
    }
    try { localStorage.setItem(KEY, json); ok = true; } catch (e) { }
    return ok;
  }

  function loadState() {
    var raw = readRaw();
    if (raw) {
      try {
        var obj = JSON.parse(raw);
        if (obj && obj.transactions) return C.normalizeState(obj);
      } catch (e) { }
    }
    return C.defaultState();
  }

  function save() {
    var ok = writeRaw(JSON.stringify(state));
    if (!ok) toast('保存失败：存储空间可能已满');
    return ok;
  }

  /* ================= 弹窗 ================= */
  function openModal(cfg) {
    $('modalTitle').textContent = cfg.title || '';
    $('modalBody').innerHTML = cfg.body || '';
    $('modalOk').textContent = cfg.okText || '确定';
    $('modal').classList.remove('hidden');
    modalOnOk = cfg.onOk || null;
    ctx.modal = cfg;
    if (cfg.focus) setTimeout(function () { var el = $(cfg.focus); if (el) el.focus(); }, 90);
  }
  function closeModal() {
    $('modal').classList.add('hidden');
    $('modalBody').innerHTML = '';
    modalOnOk = null;
  }

  function confirmDialog(title, text, onOk, okText) {
    openModal({
      title: title,
      body: '<div>' + esc(text) + '</div>',
      okText: okText || '确定',
      onOk: onOk
    });
  }

  /* ================= 视图切换 ================= */
  var VIEWS = { list: '明细', stats: '统计', big: '大件', me: '我的' };

  function switchView(v) {
    if (!VIEWS[v]) v = 'list';
    currentView = v;
    ['list', 'stats', 'big', 'me'].forEach(function (k) {
      $('view-' + k).classList.toggle('hidden', k !== v);
    });
    var tabs = $('tabbar').querySelectorAll('.tab');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.toggle('active', tabs[i].getAttribute('data-view') === v);
    }
    $('viewTitle').textContent = VIEWS[v];
    $('btnToday').classList.toggle('hidden', v !== 'list');
    renderAll();
  }

  function renderAll() {
    if (currentView === 'list') renderList();
    else if (currentView === 'stats') renderStats();
    else if (currentView === 'big') renderBig();
    else renderMe();
  }

  /* ================= 明细 ================= */
  function renderList() {
    $('monthLabel').textContent = monthLabel(listMonth);
    var s = C.monthSummary(state, listMonth);
    $('sumExpense').textContent = C.fmtMoneyGroup(s.expense);
    $('sumIncome').textContent = C.fmtMoneyGroup(s.income);
    $('sumNet').textContent = C.fmtMoneyGroup(s.net);

    var txs = C.monthTransactions(state, listMonth);
    var box = $('txList');
    if (!txs.length) {
      box.innerHTML = '<div class="empty">本月还没有记录<br><span>点右下角「＋」记一笔</span></div>';
      return;
    }
    var days = C.groupByDay(txs);
    var html = '';
    days.forEach(function (d) {
      var right = [];
      if (d.expense) right.push('支出 ' + C.fmtMoney(d.expense));
      if (d.income) right.push('收入 ' + C.fmtMoney(d.income));
      html += '<div class="daybar"><span>' + esc(dayLabel(d.day)) + '</span><em>' + esc(right.join(' · ')) + '</em></div>';
      d.items.forEach(function (t) { html += rowHTML(t); });
    });
    box.innerHTML = html;
  }

  function rowHTML(t) {
    var cat = C.findById(state.categories, t.categoryId);
    var acc = C.findById(state.accounts, t.accountId);
    var title, sub, amt, cls, icon;
    if (t.type === 'transfer') {
      var to = C.findById(state.accounts, t.toAccountId);
      title = '转账';
      sub = (acc ? acc.name : '未知') + ' → ' + (to ? to.name : '未知') + (t.note ? ' · ' + t.note : '');
      amt = C.fmtMoney(t.amount);
      cls = 'transfer';
      icon = '🔁';
    } else {
      title = cat ? cat.name : '未分类';
      sub = (acc ? acc.name : '未知') + (t.note ? ' · ' + t.note : '');
      amt = (t.type === 'income' ? '+' : '-') + C.fmtMoney(t.amount);
      cls = t.type;
      icon = iconFor(cat ? cat.name : '');
    }
    return '<div class="tx" data-id="' + esc(t.id) + '">' +
      '<div class="tx-ico">' + icon + '</div>' +
      '<div class="tx-main"><div class="tx-t">' + esc(title) + '</div><div class="tx-s">' + esc(sub) + '</div></div>' +
      '<div class="tx-a ' + cls + '">' + esc(amt) + '</div></div>';
  }

  /* ================= 统计 ================= */
  var PIE_COLORS = ['#2f6bff', '#ff7a59', '#f2b91d', '#12a150', '#a855f7', '#0ea5e9', '#ef4444', '#14b8a6', '#f472b6', '#84cc16'];
  var BIG_ICONS = { '手表': '⌚', '包袋': '👜', '珠宝': '💍', '数码': '📷', '家电': '📺', '汽车': '🚗', '其他': '💎' };

  function statsKey() { return statsMode === 'month' ? statsMonth : statsYear; }
  function statsTitle() { return statsMode === 'month' ? monthLabel(statsMonth) : (statsYear + '年'); }

  function shiftStats(d) {
    if (statsMode === 'month') statsMonth = C.shiftMonth(statsMonth, d);
    else statsYear = String(+statsYear + d);
  }

  function tile(label, value, cls) {
    return '<div class="kvv' + (cls ? ' ' + cls : '') + '"><span>' + esc(label) + '</span><b>' + esc(value) + '</b></div>';
  }

  function donutSVG(list) {
    var total = 0;
    list.forEach(function (x) { total += x.amount; });
    if (!total) total = 1;
    var off = 0, segs = '';
    list.forEach(function (x, i) {
      var len = x.amount / total * 100;
      var gap = len > 1.2 ? 0.6 : 0;
      var seg = Math.max(0.01, len - gap);
      segs += '<circle cx="21" cy="21" r="15.9155" fill="none" stroke="' + PIE_COLORS[i % PIE_COLORS.length] + '" stroke-width="7"' +
        ' stroke-dasharray="' + seg.toFixed(2) + ' ' + (100 - seg).toFixed(2) + '"' +
        ' stroke-dashoffset="' + (-off).toFixed(2) + '"></circle>';
      off += len;
    });
    return '<div class="pie"><svg viewBox="0 0 42 42" class="donut" aria-hidden="true">' +
      '<circle cx="21" cy="21" r="15.9155" fill="none" stroke="var(--line)" stroke-width="7"></circle>' +
      segs + '</svg></div>';
  }

  function pieRows(list) {
    var total = 0;
    list.forEach(function (x) { total += x.amount; });
    if (!total) total = 1;
    var h = '';
    list.forEach(function (x, i) {
      var pct = x.amount / total * 100;
      h += '<div class="prow">' +
        '<i class="pdot" style="background:' + PIE_COLORS[i % PIE_COLORS.length] + '"></i>' +
        '<div class="pn">' + esc(x.name) + '</div>' +
        '<div class="pv">' + C.fmtMoney(x.amount) + '</div>' +
        '<div class="pp">' + (pct >= 10 ? Math.round(pct) : pct.toFixed(1)) + '%</div>' +
        '</div>';
    });
    return h;
  }

  function renderStats() {
    var isYear = statsMode === 'year';
    var ov = C.overview(state, statsMode, statsKey());
    var expCats = C.categoryTotalsBetween(state, ov.from, ov.to, 'expense');
    var incCats = C.categoryTotalsBetween(state, ov.from, ov.to, 'income');
    var series = isYear ? C.yearSeries(state, statsYear) : C.daySeries(state, statsMonth);

    var html = '';

    html += '<div class="statbar">' +
      '<div class="seg2">' +
      '<button class="' + (isYear ? '' : 'on') + '" data-act="statsMode" data-mode="month">月</button>' +
      '<button class="' + (isYear ? 'on' : '') + '" data-act="statsMode" data-mode="year">年</button>' +
      '</div>' +
      '<div class="snav">' +
      '<button data-act="statsPrev" aria-label="上一期">‹</button>' +
      '<b>' + esc(statsTitle()) + '</b>' +
      '<button data-act="statsNext" aria-label="下一期">›</button>' +
      '</div></div>';

    html += '<div class="sec"><div class="sec-h"><span>数据总览</span><span>' + ov.count + ' 笔 · 活跃 ' + ov.activeDays + ' 天</span></div>' +
      '<div class="ov">' +
      tile('收入', C.fmtMoneyGroup(ov.income), 'inc') +
      tile('支出', C.fmtMoneyGroup(ov.expense), 'exp') +
      tile('结余', C.fmtMoneyGroup(ov.net), ov.net >= 0 ? 'inc' : 'exp') +
      tile('日均支出', C.fmtMoneyGroup(ov.avgPerDay)) +
      tile('最大单笔', C.fmtMoneyGroup(ov.maxAmount)) +
      tile('支出分类', String(ov.categoryCount)) +
      '</div>' +
      (ov.maxAmount ? '<div class="ovsub">最贵一笔：' + esc(ov.maxCategory || '未分类') + (ov.maxNote ? ' · ' + esc(ov.maxNote) : '') + '</div>' : '') +
      '</div>';

    if (!isYear) {
      var b = C.budgetStatus(state, statsMonth);
      if (!b.has) {
        html += '<div class="sec"><div class="sec-h"><span>本月预算</span><span>未设置</span></div>' +
          '<button class="btn" data-act="editBudget">设置本月预算</button></div>';
      } else {
        var pct = Math.min(100, Math.round(b.ratio * 100));
        html += '<div class="sec"><div class="sec-h"><span>本月预算</span><b>' + C.fmtMoneyGroup(b.budget) + '</b></div>' +
          '<div class="pbar"><i class="' + (b.over ? 'over' : (b.ratio >= 0.8 ? 'warn' : '')) + '" style="width:' + pct + '%"></i></div>' +
          '<div class="brow">' +
          '<span>已花 <b>' + C.fmtMoneyGroup(b.spent) + '</b></span>' +
          '<span class="' + (b.over ? 'over' : 'ok') + '">' + (b.over ? '超支 ' + C.fmtMoneyGroup(-b.left) : '剩余 ' + C.fmtMoneyGroup(b.left)) + '</span>' +
          '</div>' +
          '<button class="btn" data-act="editBudget">修改本月预算</button></div>';
      }
    }

    var maxV = 1;
    series.forEach(function (x) {
      if (x.expense > maxV) maxV = x.expense;
      if (x.income > maxV) maxV = x.income;
    });
    var barH = isYear ? 92 : 74;
    html += '<div class="sec"><div class="sec-h"><span>' + (isYear ? '每月收支' : '每日支出') + '</span>' +
      '<span class="lgd"><i class="dot exp"></i>支出' + (isYear ? '<i class="dot inc"></i>收入' : '') + '</span></div>' +
      '<div class="chart' + (isYear ? ' y' : '') + '">';
    series.forEach(function (x, i) {
      var h1 = Math.max(1, Math.round(x.expense / maxV * barH));
      var h2 = Math.max(1, Math.round(x.income / maxV * barH));
      var lb = '';
      if (isYear) lb = String(+String(x.key).slice(5, 7)) + '月';
      else if ((i + 1) % 5 === 0 || i === 0) lb = String(i + 1);
      html += '<div class="ccol">' +
        '<div class="cbars" style="height:' + barH + 'px">' +
        '<i class="b1" style="height:' + h1 + 'px"></i>' +
        (isYear ? '<i class="b2" style="height:' + h2 + 'px"></i>' : '') +
        '</div>' +
        '<div class="clb">' + lb + '</div>' +
        '</div>';
    });
    html += '</div></div>';

    html += '<div class="sec"><div class="sec-h"><span>支出构成</span><span>' + expCats.length + ' 类 · 共 ' + C.fmtMoneyGroup(ov.expense) + '</span></div>';
    if (!expCats.length) {
      html += '<div class="empty" style="padding:26px 0">' + (isYear ? '这一年还没有支出' : '本月还没有支出') + '</div>';
    } else {
      html += donutSVG(expCats) + '<div class="pielist">' + pieRows(expCats) + '</div>';
    }
    html += '</div>';

    html += '<div class="sec"><div class="sec-h"><span>收入构成</span><b>' + C.fmtMoneyGroup(ov.income) + '</b></div>' +
      '<div>' + (incCats.length ? incomeLines(incCats) : '<div class="empty" style="padding:18px 0">还没有收入</div>') + '</div></div>';

    $('statsBody').innerHTML = html;
  }

  function incomeLines(list) {
    if (!list.length) return '<div class="empty" style="padding:18px 0">本月还没有收入</div>';
    var h = '';
    list.forEach(function (x) {
      h += '<div class="bar-row"><div class="bn">' + esc(x.name) + '</div>' +
        '<div class="bar-wrap"><div class="bar-fill" style="width:' +
        Math.max(2, Math.round(x.amount / (list[0].amount || 1) * 100)) + '%;background:var(--income)"></div></div>' +
        '<div class="bv">' + C.fmtMoney(x.amount) + '</div></div>';
    });
    return h;
  }

  /* ================= 大件 ================= */
  function bigRowHTML(it) {
    var st = C.BIG_STATUS[it.status] || '想买';
    return '<div class="mrow" data-act="editBig" data-id="' + esc(it.id) + '">' +
      '<div class="bico">' + (BIG_ICONS[it.cat] || '💎') + '</div>' +
      '<div class="mmain">' +
      '<div class="mtitle">' + esc(it.name) + '</div>' +
      '<div class="msub">' + esc(it.cat || '其他') + ' · ' + esc(st) + (it.date ? ' · ' + esc(it.date) : '') + (it.note ? ' · ' + esc(it.note) : '') + '</div>' +
      '</div>' +
      '<div class="mprice ' + (it.status === 'bought' ? 'exp' : '') + '">¥' + C.fmtMoneyGroup(it.price) + '</div>' +
      '</div>';
  }

  function renderBig() {
    var s = C.bigItemStats(state.bigItems);
    var html = '';

    html += '<div class="sec"><div class="sec-h"><span>大件清单</span><span>' + s.count + ' 件</span></div>' +
      '<div class="ov">' +
      tile('已买金额', C.fmtMoneyGroup(s.boughtTotal), 'exp') +
      tile('想买金额', C.fmtMoneyGroup(s.wantTotal)) +
      tile('已买 / 想买', s.boughtCount + ' / ' + s.wantCount) +
      '</div>' +
      (s.max ? '<div class="ovsub">最贵一件：' + esc(s.maxName) + ' ¥' + C.fmtMoneyGroup(s.max) + '</div>' : '') +
      '</div>';

    html += '<div class="sec"><div class="sec-h"><span>记录</span><span>点条目可编辑</span></div>';
    if (!state.bigItems.length) {
      html += '<div class="empty" style="padding:34px 0">还没有记录大件<br><span>点右下角「＋」添加手表、包袋</span></div>';
    } else {
      var list = state.bigItems.slice().sort(function (a, b) { return C.num(b.price) - C.num(a.price); });
      list.forEach(function (it) { html += bigRowHTML(it); });
    }
    html += '</div>';

    html += '<div class="sec"><div class="sec-h"><span>说明</span></div>' +
      '<div class="hint">大件只记录贵重物品的价格，<b>不会计进「明细」的支出流水</b>，避免和真实付款重复统计。' +
      '如果当月确实付了钱，再到「明细」里记一笔即可。</div></div>';

    $('bigBody').innerHTML = html;
  }

  function bigModal(item) {
    var it = item || { id: '', name: '', price: '', date: C.todayStr(), cat: '其他', status: 'want', note: '' };
    var catOpts = C.BIG_CATS.map(function (x) {
      return '<option value="' + esc(x) + '"' + (x === it.cat ? ' selected' : '') + '>' + esc(x) + '</option>';
    }).join('');
    var body = '<label class="fl">名称<input id="mName" class="ipt" value="' + esc(it.name) + '" placeholder="如 机械表 / 相机"></label>' +
      '<label class="fl">价格<input id="mPrice" class="ipt" inputmode="decimal" value="' + (it.price === '' ? '' : esc(String(it.price))) + '" placeholder="0.00"></label>' +
      '<label class="fl">品类<select id="mCat" class="ipt">' + catOpts + '</select></label>' +
      '<label class="fl">状态<select id="mStat" class="ipt">' +
      '<option value="want"' + (it.status === 'want' ? ' selected' : '') + '>想买</option>' +
      '<option value="bought"' + (it.status === 'bought' ? ' selected' : '') + '>已买</option>' +
      '</select></label>' +
      '<label class="fl">日期<input id="mDate" class="ipt" value="' + esc(it.date || C.todayStr()) + '" placeholder="YYYY-MM-DD"></label>' +
      '<label class="fl">备注<input id="mNote" class="ipt" value="' + esc(it.note || '') + '" placeholder="选填"></label>' +
      (item ? '<button class="btn danger" data-act="delBig" data-id="' + esc(it.id) + '">删除这条</button>' : '');
    openModal({
      title: item ? '编辑大件' : '添加大件',
      body: body,
      okText: '保存',
      onOk: function () {
        var name = $('mName').value.trim();
        var price = C.parseAmount($('mPrice').value);
        if (!name) { toast('请填写名称'); return false; }
        if (!(price > 0)) { toast('价格要大于 0'); return false; }
        var obj = {
          id: item ? item.id : C.uid('big'),
          name: name,
          price: price,
          cat: $('mCat').value,
          status: $('mStat').value,
          date: $('mDate').value.trim() || C.todayStr(),
          note: $('mNote').value.trim()
        };
        if (item) {
          var idx = state.bigItems.findIndex(function (x) { return x.id === item.id; });
          if (idx >= 0) state.bigItems[idx] = obj; else state.bigItems.push(obj);
        } else {
          state.bigItems.push(obj);
        }
        save();
        renderAll();
        toast(item ? '已更新' : '已添加');
        return true;
      }
    });
  }

  function delBig(id) {
    var idx = state.bigItems.findIndex(function (x) { return x.id === id; });
    if (idx < 0) { toast('找不到这条'); return; }
    var name = state.bigItems[idx].name;
    state.bigItems.splice(idx, 1);
    save();
    renderAll();
    closeModal();
    toast('已删除「' + name + '」');
  }

  function editBudget() {
    var cur = C.budgetOf(state, statsMonth);
    openModal({
      title: '设置 ' + monthLabel(statsMonth) + ' 预算',
      body: '<label class="fl">本月支出预算<input id="mBudget" class="ipt" inputmode="decimal" value="' + (cur ? esc(String(cur)) : '') + '" placeholder="填 0 表示取消预算"></label>' +
        '<div class="hint">预算按月保存，只统计当月的支出流水。</div>',
      okText: '保存',
      onOk: function () {
        var v = C.parseAmount($('mBudget').value);
        C.setBudget(state, statsMonth, v);
        save();
        renderAll();
        toast(v > 0 ? '预算已设置' : '已取消预算');
        return true;
      }
    });
  }

  /* ================= 我的 ================= */
  function renderMe() {
    var total = 0;
    state.accounts.forEach(function (a) { total += C.accountBalance(state, a.id); });

    var html = '';
    html += '<div class="sec"><div class="sec-h"><span>我的账户</span><b>' + C.fmtMoneyGroup(total) + '</b></div>';
    if (!state.accounts.length) {
      html += '<div class="empty" style="padding:20px 0">还没有账户</div>';
    }
    state.accounts.forEach(function (a) {
      html += '<div class="row" data-act="editAcc" data-id="' + esc(a.id) + '">' +
        '<div class="r-main"><div class="r-t">' + esc(a.name) + '</div>' +
        '<div class="r-s">' + esc(C.ACC_TYPES[a.type] || a.type) + '</div></div>' +
        '<div class="r-v">' + C.fmtMoneyGroup(C.accountBalance(state, a.id)) + '</div>' +
        '</div>';
    });
    html += '<button class="btn" data-act="addAcc">＋ 添加账户</button></div>';

    var expCats = state.categories.filter(function (c) { return c.type === 'expense'; });
    var incCats = state.categories.filter(function (c) { return c.type === 'income'; });

    html += '<div class="sec"><div class="sec-h"><span>支出分类</span><b>' + expCats.length + '</b></div><div class="chips">';
    expCats.forEach(function (c) {
      html += '<button class="chip" data-act="editCat" data-id="' + esc(c.id) + '">' + esc(c.name) + '</button>';
    });
    html += '<button class="chip add" data-act="addCat" data-t="expense">＋ 添加</button></div></div>';

    html += '<div class="sec"><div class="sec-h"><span>收入分类</span><b>' + incCats.length + '</b></div><div class="chips">';
    incCats.forEach(function (c) {
      html += '<button class="chip" data-act="editCat" data-id="' + esc(c.id) + '">' + esc(c.name) + '</button>';
    });
    html += '<button class="chip add" data-act="addCat" data-t="income">＋ 添加</button></div></div>';

    html += '<div class="sec"><div class="sec-h"><span>数据</span><span>' + state.transactions.length + ' 笔 · 大件 ' + state.bigItems.length + '</span></div>' +
      '<button class="btn" data-act="addBig">＋ 添加大件</button>' +
      '<button class="btn" data-act="expCSV">导出 CSV（Excel 可打开）</button>' +
      '<button class="btn" data-act="expJSON">导出完整备份（JSON）</button>' +
      '<button class="btn" data-act="impFile">从文件导入</button>' +
      '<button class="btn" data-act="impPaste">粘贴文本导入</button>' +
      '<button class="btn warn" data-act="clearAll">清空全部数据</button></div>';

    html += '<div class="sec"><div class="sec-h"><span>关于</span><span>v' + APP_VER + '</span></div>' +
      '<div style="font-size:12.5px;line-height:1.8;color:var(--text2)">' +
      '数据只保存在这台手机上，不联网、不上传。<br>' +
      '统计页可切「月 / 年」，看柱状图、饼图和数据总览；月视图下能设本月预算。<br>' +
      '「大件」用来记手表、包这类贵重物品，单独统计，不计入明细支出。<br>' +
      '导入格式：<b>交易时间, 交易类型, 金额, 分类, 账户, 备注</b>，<br>' +
      '交易类型填「支出 / 收入」，金额可为负数，<br>示例：2026-11-03 12:30, 支出, -28.5, 餐饮, 微信零钱, 午饭。' +
      '</div></div>';

    $('meBody').innerHTML = html;
  }

  /* ================= 记一笔 ================= */
  function mostUsedCat(type) {
    var cnt = {}, best = null, bestN = 0;
    state.transactions.forEach(function (t) {
      if (t.type !== type || !t.categoryId) return;
      cnt[t.categoryId] = (cnt[t.categoryId] || 0) + 1;
      if (cnt[t.categoryId] > bestN) { bestN = cnt[t.categoryId]; best = t.categoryId; }
    });
    if (best && C.findById(state.categories, best)) return best;
    var first = state.categories.filter(function (c) { return c.type === type; })[0];
    return first ? first.id : null;
  }

  function openSheet(tx) {
    if (!state.accounts.length) { toast('请先在「我的」里添加一个账户'); return; }
    if (tx) {
      draft = {
        id: tx.id, type: tx.type, amount: C.fmtMoney(tx.amount),
        categoryId: tx.categoryId, accountId: tx.accountId,
        toAccountId: tx.toAccountId, date: C.dayOf(tx.time), note: tx.note || ''
      };
    } else {
      var accId = state.settings.defaultAccountId;
      if (!C.findById(state.accounts, accId)) accId = state.accounts[0].id;
      draft = {
        id: null, type: 'expense', amount: '',
        categoryId: mostUsedCat('expense'), accountId: accId,
        toAccountId: null, date: C.todayStr(), note: ''
      };
    }
    renderSheet();
    $('sheet').classList.remove('hidden');
    $('sheetMask').classList.remove('hidden');
    setTimeout(function () { try { $('fAmount').focus(); } catch (e) { } }, 80);
  }

  function renderSheet() {
    if (!draft) return;
    var segs = $('typeSeg').querySelectorAll('button');
    for (var i = 0; i < segs.length; i++) {
      segs[i].classList.toggle('on', segs[i].getAttribute('data-t') === draft.type);
    }
    $('sheetDelete').classList.toggle('hidden', !draft.id);
    $('gCat').classList.toggle('hidden', draft.type === 'transfer');
    $('gToAcc').classList.toggle('hidden', draft.type !== 'transfer');
    $('gAccLabel').textContent = draft.type === 'transfer' ? '转出账户' : '账户';
    $('fAmount').value = draft.amount || '';
    $('fDate').value = draft.date || C.todayStr();
    $('fNote').value = draft.note || '';

    if (draft.type !== 'transfer') {
      if (!draft.categoryId) draft.categoryId = mostUsedCat(draft.type);
      var cs = state.categories.filter(function (c) { return c.type === draft.type; });
      var h = '';
      cs.forEach(function (c) {
        h += '<button class="chip' + (c.id === draft.categoryId ? ' on' : '') + '" data-act="pickCat" data-id="' + esc(c.id) + '">' +
          iconFor(c.name) + ' ' + esc(c.name) + '</button>';
      });
      h += '<button class="chip add" data-act="addCatQuick">＋ 新分类</button>';
      $('fCats').innerHTML = h;
    }

    var ah = '';
    state.accounts.forEach(function (a) {
      ah += '<button class="chip' + (a.id === draft.accountId ? ' on' : '') + '" data-act="pickAcc" data-id="' + esc(a.id) + '">' + esc(a.name) + '</button>';
    });
    $('fAccs').innerHTML = ah;

    if (draft.type === 'transfer') {
      var th = '';
      state.accounts.forEach(function (a) {
        th += '<button class="chip' + (a.id === draft.toAccountId ? ' on' : '') + '" data-act="pickToAcc" data-id="' + esc(a.id) + '">' + esc(a.name) + '</button>';
      });
      $('fToAccs').innerHTML = th;
    }
  }

  function closeSheet() {
    $('sheet').classList.add('hidden');
    $('sheetMask').classList.add('hidden');
    draft = null;
  }

  function saveTx() {
    if (!draft) return;
    var amount = C.parseAmount($('fAmount').value);
    if (amount === null || amount <= 0) { toast('请输入大于 0 的金额'); return; }
    if (!draft.accountId) { toast('请选择账户'); return; }
    if (draft.type !== 'transfer' && !draft.categoryId) { toast('请选择分类'); return; }
    if (draft.type === 'transfer') {
      if (!draft.toAccountId) { toast('请选择转入账户'); return; }
      if (draft.toAccountId === draft.accountId) { toast('转出和转入不能是同一个账户'); return; }
    }

    var dateVal = $('fDate').value;
    var base = C.normalizeDateTime(dateVal) || (C.todayStr() + ' 00:00:00');
    var dayPart = base.slice(0, 10);
    var hms;
    if (draft.id) {
      var old = C.findById(state.transactions, draft.id);
      hms = old ? String(old.time).slice(11, 19) : C.nowStr().slice(11, 19);
    } else {
      hms = C.nowStr().slice(11, 19);
    }
    if (!/^\d{2}:\d{2}:\d{2}$/.test(hms)) hms = '00:00:00';
    var time = dayPart + ' ' + hms;

    var note = ($('fNote').value || '').trim();
    var isEdit = !!draft.id;

    if (isEdit) {
      var t = C.findById(state.transactions, draft.id);
      if (t) {
        t.type = draft.type;
        t.amount = amount;
        t.time = time;
        t.note = note;
        t.accountId = draft.accountId;
        t.categoryId = draft.type === 'transfer' ? null : draft.categoryId;
        t.toAccountId = draft.type === 'transfer' ? draft.toAccountId : null;
      }
    } else {
      state.transactions.push({
        id: C.uid('tx'),
        type: draft.type,
        time: time,
        amount: amount,
        categoryId: draft.type === 'transfer' ? null : draft.categoryId,
        accountId: draft.accountId,
        toAccountId: draft.type === 'transfer' ? draft.toAccountId : null,
        note: note,
        createdAt: C.nowStr()
      });
    }

    state.settings.defaultAccountId = draft.accountId;
    save();
    listMonth = C.monthOf(time);
    closeSheet();
    toast(isEdit ? '已保存' : '记账成功');
    if (currentView !== 'list') switchView('list'); else renderList();
  }

  function delTx() {
    if (!draft || !draft.id) return;
    var id = draft.id;
    confirmDialog('删除这笔记录', '删除后无法恢复，确定吗？', function () {
      state.transactions = state.transactions.filter(function (t) { return t.id !== id; });
      save();
      closeModal();
      closeSheet();
      toast('已删除');
      renderAll();
    }, '删除');
  }

  /* ================= 账户 / 分类 ================= */
  function typeOptions(sel) {
    var h = '';
    Object.keys(C.ACC_TYPES).forEach(function (k) {
      h += '<option value="' + k + '"' + (k === sel ? ' selected' : '') + '>' + C.ACC_TYPES[k] + '</option>';
    });
    return h;
  }

  function addAcc() {
    openModal({
      title: '添加账户',
      body: '<input id="mName" placeholder="账户名称，如 招商银行">' +
        '<input id="mOpen" inputmode="decimal" placeholder="期初余额（可不填）" style="margin-top:8px">' +
        '<select id="mType" style="margin-top:8px">' + typeOptions('wallet') + '</select>' +
        '<div class="hint">期初余额可以填你现在这个账户里实际有多少钱。</div>',
      focus: 'mName',
      onOk: function () {
        var name = ($('mName').value || '').trim();
        if (!name) { toast('请填写账户名称'); return false; }
        if (C.findByName(state.accounts, name)) { toast('已有同名账户'); return false; }
        var open = C.parseAmount($('mOpen').value);
        state.accounts.push({
          id: C.uid('acc'), name: name,
          type: $('mType').value || 'wallet',
          openingBalance: open === null ? 0 : open
        });
        save(); closeModal(); toast('已添加账户'); renderAll();
      }
    });
  }

  function editAcc(id) {
    var a = C.findById(state.accounts, id);
    if (!a) return;
    var used = state.transactions.filter(function (t) { return t.accountId === id || t.toAccountId === id; }).length;
    openModal({
      title: '编辑账户',
      body: '<input id="mName" value="' + esc(a.name) + '">' +
        '<input id="mOpen" inputmode="decimal" value="' + esc(C.fmtMoney(a.openingBalance)) + '" style="margin-top:8px">' +
        '<select id="mType" style="margin-top:8px">' + typeOptions(a.type) + '</select>' +
        '<div class="hint">期初余额 = 开始记账时该账户已有的钱。<br>这个账户已被 ' + used + ' 笔记录使用。</div>' +
        '<button class="btn warn" data-act="delAcc" data-id="' + esc(id) + '" style="margin-top:12px">删除此账户</button>',
      onOk: function () {
        var name = ($('mName').value || '').trim();
        if (!name) { toast('请填写账户名称'); return false; }
        var dup = C.findByName(state.accounts, name);
        if (dup && dup.id !== id) { toast('已有同名账户'); return false; }
        var open = C.parseAmount($('mOpen').value);
        a.name = name;
        a.type = $('mType').value || a.type;
        a.openingBalance = open === null ? 0 : open;
        save(); closeModal(); toast('已保存'); renderAll();
      }
    });
  }

  function delAcc(id) {
    var used = state.transactions.filter(function (t) { return t.accountId === id || t.toAccountId === id; }).length;
    if (used) { toast('该账户还有 ' + used + ' 笔记录，不能删除'); return; }
    if (state.accounts.length <= 1) { toast('至少保留一个账户'); return; }
    confirmDialog('删除账户', '确定删除这个账户吗？', function () {
      state.accounts = state.accounts.filter(function (a) { return a.id !== id; });
      if (state.settings.defaultAccountId === id) {
        state.settings.defaultAccountId = state.accounts.length ? state.accounts[0].id : null;
      }
      save(); closeModal(); toast('已删除'); renderAll();
    }, '删除');
  }

  function addCat(type) {
    openModal({
      title: type === 'income' ? '添加收入分类' : '添加支出分类',
      body: '<input id="mName" placeholder="分类名称，如 咖啡">',
      focus: 'mName',
      onOk: function () {
        var name = ($('mName').value || '').trim();
        if (!name) { toast('请填写名称'); return false; }
        if (C.findByName(state.categories, name, type)) { toast('已有同名分类'); return false; }
        state.categories.push({ id: C.uid('cat'), name: name, type: type });
        save(); closeModal(); toast('已添加'); renderAll();
      }
    });
  }

  function editCat(id) {
    var c = C.findById(state.categories, id);
    if (!c) return;
    var used = state.transactions.filter(function (t) { return t.categoryId === id; }).length;
    openModal({
      title: '编辑分类',
      body: '<input id="mName" value="' + esc(c.name) + '">' +
        '<div class="hint">已被 ' + used + ' 笔记录使用。</div>' +
        '<button class="btn warn" data-act="delCat" data-id="' + esc(id) + '" style="margin-top:12px">删除此分类</button>',
      onOk: function () {
        var name = ($('mName').value || '').trim();
        if (!name) { toast('请填写名称'); return false; }
        var dup = C.findByName(state.categories, name, c.type);
        if (dup && dup.id !== id) { toast('已有同名分类'); return false; }
        c.name = name;
        save(); closeModal(); toast('已保存'); renderAll();
      }
    });
  }

  function delCat(id) {
    var used = state.transactions.filter(function (t) { return t.categoryId === id; }).length;
    if (used) { toast('该分类还有 ' + used + ' 笔记录，不能删除'); return; }
    confirmDialog('删除分类', '确定删除这个分类吗？', function () {
      state.categories = state.categories.filter(function (c) { return c.id !== id; });
      save(); closeModal(); toast('已删除'); renderAll();
    }, '删除');
  }

  /* ================= 数据 ================= */
  function saveTextFile(name, content) {
    if (Native && typeof Native.saveFile === 'function') {
      try {
        var p = Native.saveFile(name, content);
        if (p) { toast('已保存到 ' + p); return; }
      } catch (e) { }
    }
    try {
      var blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name;
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); if (a.parentNode) a.parentNode.removeChild(a); }, 1500);
      toast('已导出 ' + name);
    } catch (e) {
      toast('导出失败，请改用「粘贴文本导入」里的复制方式');
    }
  }

  function exportCSV() {
    if (!state.transactions.length) { toast('还没有任何记录'); return; }
    saveTextFile('小账本-' + C.todayStr() + '.csv', C.transactionsToCSV(state));
  }

  function exportJSON() {
    saveTextFile('小账本备份-' + C.todayStr() + '.json', JSON.stringify({
      app: 'xiaozhangben', version: 1, exportedAt: C.nowStr(),
      accounts: state.accounts, categories: state.categories,
      transactions: state.transactions, bigItems: state.bigItems,
      settings: state.settings
    }, null, 1));
  }

  function reportImport(res, isJSON) {
    var msg = '';
    if (isJSON) {
      msg = '已恢复 ' + res.count + ' 笔记录。';
    } else {
      var n = res.created ? res.created.length : 0;
      var errs = res.errors || [];
      msg = '成功导入 ' + n + ' 笔。';
      if (errs.length) msg += '跳过 ' + errs.length + ' 行。';
      if (errs.length) {
        var lines = errs.slice(0, 8).map(function (e) { return '第' + e.line + '行：' + e.reason; }).join('\n');
        msg += '\n\n' + lines + (errs.length > 8 ? '\n…' : '');
      }
    }
    openModal({
      title: '导入结果',
      body: '<div style="white-space:pre-wrap">' + esc(msg) + '</div>',
      okText: '好的'
    });
  }

  function importText(text, fname) {
    text = String(text || '').replace(/^\uFEFF/, '').trim();
    if (!text) { toast('文件内容为空'); return; }
    var first = text.charAt(0);
    if (first === '{' || first === '[') {
      var obj;
      try { obj = JSON.parse(text); } catch (e) { toast('JSON 格式错误'); return; }
      if (Array.isArray(obj)) obj = { transactions: obj };
      if (!obj || !Array.isArray(obj.transactions)) { toast('这不是有效的备份文件'); return; }
      confirmDialog('恢复备份', '将用备份内容覆盖当前全部数据（现有 ' + state.transactions.length + ' 笔记录会被替换），确定吗？', function () {
        state = C.normalizeState(obj);
        save();
        var n = state.transactions.length;
        renderAll();
        openModal({
          title: '导入结果',
          body: '<div>已恢复 ' + n + ' 笔记录。</div>',
          okText: '好的'
        });
        toast('已恢复备份');
        return false;
      }, '覆盖恢复');
      return;
    }
    var res = C.importCSV(text, state);
    if (res.created && res.created.length) {
      save();
      renderAll();
    }
    reportImport(res, false);
  }

  function importFile() {
    var input = $('fileInput');
    input.value = '';
    input.onchange = function () {
      var f = input.files && input.files[0];
      if (!f) return;
      var reader = new FileReader();
      reader.onload = function () { importText(reader.result, f.name); };
      reader.onerror = function () { toast('读取文件失败'); };
      reader.readAsText(f, 'utf-8');
    };
    input.click();
  }

  function importPaste() {
    openModal({
      title: '粘贴文本导入',
      body: '<textarea id="mPaste" placeholder="把 CSV 内容粘贴到这里，第一行是表头：&#10;交易时间,交易类型,金额,分类,账户,备注&#10;2026-11-03 12:30,支出,-28.5,餐饮,微信零钱,午饭"></textarea>' +
        '<div class="hint">支持从 Excel / 公众号账单 / 其他记账软件复制的文本。可自动识别 <b>时间、类型、金额、分类、账户、备注</b> 这些列，缺失的分类和账户会自动创建。</div>',
      onOk: function () {
        var t = $('mPaste').value;
        if (!t || !t.trim()) { toast('请先粘贴内容'); return false; }
        importText(t);
        return false;
      }
    });
  }

  function clearAll() {
    confirmDialog('清空全部数据', '所有账户、分类和 ' + state.transactions.length + ' 笔记录都会被删除，且无法恢复。建议先导出备份。', function () {
      state = C.defaultState();
      save();
      closeModal();
      listMonth = C.monthOf(C.nowStr());
      toast('已清空');
      renderAll();
    }, '确认清空');
  }

  /* ================= 事件 ================= */
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.closest) return;

    var actEl = t.closest('[data-act]');
    if (actEl) {
      var act = actEl.getAttribute('data-act');
      var id = actEl.getAttribute('data-id');
      switch (act) {
        case 'tab': switchView(actEl.getAttribute('data-view')); return;
        case 'add':
          if (currentView === 'big') bigModal(null); else openSheet(null);
          return;
        case 'today':
          listMonth = C.monthOf(C.nowStr());
          if (currentView !== 'list') switchView('list'); else renderList();
          return;
        case 'prevMonth': listMonth = C.shiftMonth(listMonth, -1); renderAll(); return;
        case 'nextMonth': listMonth = C.shiftMonth(listMonth, 1); renderAll(); return;
        case 'statsMode':
          statsMode = actEl.getAttribute('data-mode') === 'year' ? 'year' : 'month';
          renderAll(); return;
        case 'statsPrev': shiftStats(-1); renderAll(); return;
        case 'statsNext': shiftStats(1); renderAll(); return;
        case 'editBudget': editBudget(); return;
        case 'addBig': bigModal(null); return;
        case 'editBig':
          var bi = C.findById(state.bigItems, id);
          if (bi) bigModal(bi);
          return;
        case 'delBig': delBig(id); return;
        case 'closeSheet': closeSheet(); return;
        case 'saveTx': saveTx(); return;
        case 'delTx': delTx(); return;
        case 'setType':
          if (!draft) return;
          draft.type = actEl.getAttribute('data-t');
          if (draft.type === 'transfer') {
            draft.categoryId = null;
            if (draft.toAccountId === draft.accountId) draft.toAccountId = null;
          } else {
            draft.categoryId = mostUsedCat(draft.type);
          }
          renderSheet(); return;
        case 'pickCat':
          if (draft) { draft.categoryId = id; renderSheet(); }
          return;
        case 'pickAcc':
          if (draft) { draft.accountId = id; renderSheet(); }
          return;
        case 'pickToAcc':
          if (draft) { draft.toAccountId = id; renderSheet(); }
          return;
        case 'addCatQuick':
          if (!draft) return;
          addCat(draft.type);
          return;
        case 'addAcc': addAcc(); return;
        case 'editAcc': editAcc(id); return;
        case 'delAcc': delAcc(id); return;
        case 'addCat': addCat(actEl.getAttribute('data-t') || 'expense'); return;
        case 'editCat': editCat(id); return;
        case 'delCat': delCat(id); return;
        case 'expCSV': exportCSV(); return;
        case 'expJSON': exportJSON(); return;
        case 'impFile': importFile(); return;
        case 'impPaste': importPaste(); return;
        case 'clearAll': clearAll(); return;
        case 'modalCancel': closeModal(); return;
        case 'modalOk':
          var r = modalOnOk ? modalOnOk() : undefined;
          if (r !== false) closeModal();
          return;
      }
      return;
    }

    var txEl = t.closest('.tx');
    if (txEl && txEl.getAttribute('data-id')) {
      var tx = C.findById(state.transactions, txEl.getAttribute('data-id'));
      if (tx) openSheet(tx);
    }
  });

  window.__errCount = 0;
  window.addEventListener('error', function (ev) {
    if (window.__errCount >= 3) return;
    window.__errCount++;
    var m = ev && ev.message ? ev.message : '未知错误';
    toast('脚本异常：' + m);
  });

  /* ================= 启动 ================= */
  function boot() {
    state = loadState();
    save();
    switchView('list');
    if (!state.transactions.length) {
      setTimeout(function () { toast('点右下角「＋」记第一笔'); }, 700);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
