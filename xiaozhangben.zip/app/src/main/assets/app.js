/* 小账本 · 界面层 */
(function () {
  'use strict';

  var C = window.Core;
  var KEY = 'xiaozhangben.v1';
  var Native = window.AndroidBridge || null;
  var APP_VER = '1.0.0';

  var state = null;
  var listMonth = C.monthOf(C.nowStr());
  var currentView = 'list';
  var draft = null;
  var modalOnOk = null;
  var ctx = {};

  /* ================= 基础工具 ================= */
  function $(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  var toastTimer = null;
  function toast(msg) {
    var el = $('toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.remove('hidden');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.add('hidden'); }, 2400);
  }

  var ICONS = {
    '餐饮': '🍜', '交通': '🚌', '购物': '🛍', '居住': '🏠', '娱乐': '🎮',
    '医疗': '💊', '学习': '📚', '人情': '🎁', '其他': '📦', '其他收入': '💵',
    '工资': '💰', '奖金': '🏆', '理财': '📈', '红包': '🧧'
  };
  function iconFor(name) { return ICONS[name] || '💳'; }

  function daysInMonth(m) {
    var p = String(m).split('-');
    return new Date(+p[0], +p[1], 0).getDate();
  }

  var WD = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  function dayLabel(day) {
    var p = String(day).split('-');
    var d = new Date(+p[0], +p[1] - 1, +p[2]);
    var nowY = new Date().getFullYear();
    var head = (+p[0] === nowY) ? (p[1] + '-' + p[2]) : (p[0] + '-' + p[1] + '-' + p[2]);
    return head + ' ' + (WD[d.getDay()] || '');
  }
  function monthLabel(m) {
    var p = String(m).split('-');
    return p[0] + '年' + (+p[1]) + '月';
  }

  /* ================= 存储 ================= */
  function readRaw() {
    if (Native && typeof Native.readData === 'function') {
      try { var s = Native.readData(); if (s) return s; } catch (e) { }
    }
    try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; }
  }

  function writeRaw(json) {
    var ok = false;
    if (Native && typeof Native.writeData === 'function') {
      try { ok = !!Native.writeData(json); } catch (e) { }
    }
    try { localStorage.setItem(KEY, json); ok = true; } catch (e) { }
    return ok;
  }

  function loadState() {
    var raw = readRaw();
    if (raw) {
      try {
        var obj = JSON.parse(raw);
        if (obj && obj.transactions) return C.normalizeState(obj);
      } catch (e) { }
    }
    return C.defaultState();
  }

  function save() {
    var ok = writeRaw(JSON.stringify(state));
    if (!ok) toast('保存失败：存储空间可能已满');
    return ok;
  }

  /* ================= 弹窗 ================= */
  function openModal(cfg) {
    $('modalTitle').textContent = cfg.title || '';
    $('modalBody').innerHTML = cfg.body || '';
    $('modalOk').textContent = cfg.okText || '确定';
    $('modal').classList.remove('hidden');
    modalOnOk = cfg.onOk || null;
    ctx.modal = cfg;
    if (cfg.focus) setTimeout(function () { var el = $(cfg.focus); if (el) el.focus(); }, 90);
  }
  function closeModal() {
    $('modal').classList.add('hidden');
    $('modalBody').innerHTML = '';
    modalOnOk = null;
  }

  function confirmDialog(title, text, onOk, okText) {
    openModal({
      title: title,
      body: '<div>' + esc(text) + '</div>',
      okText: okText || '确定',
      onOk: onOk
    });
  }

  /* ================= 视图切换 ================= */
  function switchView(v) {
    currentView = v;
    ['list', 'stats', 'me'].forEach(function (k) {
      $('view-' + k).classList.toggle('hidden', k !== v);
    });
    var tabs = $('tabbar').querySelectorAll('.tab');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.toggle('active', tabs[i].getAttribute('data-view') === v);
    }
    $('viewTitle').textContent = v === 'list' ? '明细' : (v === 'stats' ? '统计' : '我的');
    $('btnToday').classList.toggle('hidden', v !== 'list');
    renderAll();
  }

  function renderAll() {
    if (currentView === 'list') renderList();
    else if (currentView === 'stats') renderStats();
    else renderMe();
  }

  /* ================= 明细 ================= */
  function renderList() {
    $('monthLabel').textContent = monthLabel(listMonth);
    var s = C.monthSummary(state, listMonth);
    $('sumExpense').textContent = C.fmtMoneyGroup(s.expense);
    $('sumIncome').textContent = C.fmtMoneyGroup(s.income);
    $('sumNet').textContent = C.fmtMoneyGroup(s.net);

    var txs = C.monthTransactions(state, listMonth);
    var box = $('txList');
    if (!txs.length) {
      box.innerHTML = '<div class="empty">本月还没有记录<br><span>点右下角「＋」记一笔</span></div>';
      return;
    }
    var days = C.groupByDay(txs);
    var html = '';
    days.forEach(function (d) {
      var right = [];
      if (d.expense) right.push('支出 ' + C.fmtMoney(d.expense));
      if (d.income) right.push('收入 ' + C.fmtMoney(d.income));
      html += '<div class="daybar"><span>' + esc(dayLabel(d.day)) + '</span><em>' + esc(right.join(' · ')) + '</em></div>';
      d.items.forEach(function (t) { html += rowHTML(t); });
    });
    box.innerHTML = html;
  }

  function rowHTML(t) {
    var cat = C.findById(state.categories, t.categoryId);
    var acc = C.findById(state.accounts, t.accountId);
    var title, sub, amt, cls, icon;
    if (t.type === 'transfer') {
      var to = C.findById(state.accounts, t.toAccountId);
      title = '转账';
      sub = (acc ? acc.name : '未知') + ' → ' + (to ? to.name : '未知') + (t.note ? ' · ' + t.note : '');
      amt = C.fmtMoney(t.amount);
      cls = 'transfer';
      icon = '🔁';
    } else {
      title = cat ? cat.name : '未分类';
      sub = (acc ? acc.name : '未知') + (t.note ? ' · ' + t.note : '');
      amt = (t.type === 'income' ? '+' : '-') + C.fmtMoney(t.amount);
      cls = t.type;
      icon = iconFor(cat ? cat.name : '');
    }
    return '<div class="tx" data-id="' + esc(t.id) + '">' +
      '<div class="tx-ico">' + icon + '</div>' +
      '<div class="tx-main"><div class="tx-t">' + esc(title) + '</div><div class="tx-s">' + esc(sub) + '</div></div>' +
      '<div class="tx-a ' + cls + '">' + esc(amt) + '</div></div>';
  }

  /* ================= 统计 ================= */
  function renderStats() {
    var m = listMonth;
    var s = C.monthSummary(state, m);
    var dim = daysInMonth(m);
    var avg = s.expense / dim;
    var ct = C.categoryTotals(state, m, 'expense');
    var max = 1;
    ct.forEach(function (x) { if (x.amount > max) max = x.amount; });

    var html = '';
    html += '<div class="sec"><div class="sec-h"><span>' + esc(monthLabel(m)) + '</span><b>' + C.fmtMoneyGroup(s.net) + '</b></div>' +
      '<div class="kv">' +
      '<div><span>支出</span><b style="color:var(--expense)">' + C.fmtMoneyGroup(s.expense) + '</b></div>' +
      '<div><span>收入</span><b style="color:var(--income)">' + C.fmtMoneyGroup(s.income) + '</b></div>' +
      '<div><span>笔数</span><b>' + s.count + '</b></div>' +
      '</div>' +
      '<div class="kv" style="margin-top:12px"><div><span>日均支出</span><b>' + C.fmtMoneyGroup(avg) + '</b></div></div>' +
      '</div>';

    html += '<div class="sec"><div class="sec-h"><span>支出构成</span><b>' + ct.length + ' 类</b></div>';
    if (!ct.length) {
      html += '<div class="empty" style="padding:26px 0">本月还没有支出</div>';
    } else {
      ct.forEach(function (x) {
        html += '<div class="bar-row">' +
          '<div class="bn">' + esc(x.name) + '</div>' +
          '<div class="bar-wrap"><div class="bar-fill" style="width:' + Math.max(2, Math.round(x.amount / max * 100)) + '%"></div></div>' +
          '<div class="bv">' + C.fmtMoney(x.amount) + '</div>' +
          '</div>';
      });
    }
    html += '</div>';

    var trend = C.monthlyTrend(state, m, 6);
    var tmax = 1;
    trend.forEach(function (x) { if (x.expense > tmax) tmax = x.expense; if (x.income > tmax) tmax = x.income; });
    html += '<div class="sec"><div class="sec-h"><span>近 6 个月</span><span>红=支出 绿=收入</span></div><div class="trend">';
    trend.forEach(function (x) {
      var h1 = Math.max(2, Math.round(x.expense / tmax * 88));
      var h2 = Math.max(2, Math.round(x.income / tmax * 88));
      html += '<div class="tcol"><div class="tbars">' +
        '<i class="b1" style="height:' + h1 + 'px"></i>' +
        '<i class="b2" style="height:' + h2 + 'px"></i>' +
        '</div><div class="lb">' + (+String(x.month).split('-')[1]) + '月</div></div>';
    });
    html += '</div></div>';

    html += '<div class="sec"><div class="sec-h"><span>本月收入</span><b>' + C.fmtMoneyGroup(s.income) + '</b></div>' +
      '<div>' + incomeLines(C.categoryTotals(state, m, 'income')) + '</div></div>';

    $('statsBody').innerHTML = html;
  }

  function incomeLines(list) {
    if (!list.length) return '<div class="empty" style="padding:18px 0">本月还没有收入</div>';
    var h = '';
    list.forEach(function (x) {
      h += '<div class="bar-row"><div class="bn">' + esc(x.name) + '</div>' +
        '<div class="bar-wrap"><div class="bar-fill" style="width:' +
        Math.max(2, Math.round(x.amount / (list[0].amount || 1) * 100)) + '%;background:var(--income)"></div></div>' +
        '<div class="bv">' + C.fmtMoney(x.amount) + '</div></div>';
    });
    return h;
  }

  /* ================= 我的 ================= */
  function renderMe() {
    var total = 0;
    state.accounts.forEach(function (a) { total += C.accountBalance(state, a.id); });

    var html = '';
    html += '<div class="sec"><div class="sec-h"><span>我的账户</span><b>' + C.fmtMoneyGroup(total) + '</b></div>';
    if (!state.accounts.length) {
      html += '<div class="empty" style="padding:20px 0">还没有账户</div>';
    }
    state.accounts.forEach(function (a) {
      html += '<div class="row" data-act="editAcc" data-id="' + esc(a.id) + '">' +
        '<div class="r-main"><div class="r-t">' + esc(a.name) + '</div>' +
        '<div class="r-s">' + esc(C.ACC_TYPES[a.type] || a.type) + '</div></div>' +
        '<div class="r-v">' + C.fmtMoneyGroup(C.accountBalance(state, a.id)) + '</div>' +
        '</div>';
    });
    html += '<button class="btn" data-act="addAcc">＋ 添加账户</button></div>';

    var expCats = state.categories.filter(function (c) { return c.type === 'expense'; });
    var incCats = state.categories.filter(function (c) { return c.type === 'income'; });

    html += '<div class="sec"><div class="sec-h"><span>支出分类</span><b>' + expCats.length + '</b></div><div class="chips">';
    expCats.forEach(function (c) {
      html += '<button class="chip" data-act="editCat" data-id="' + esc(c.id) + '">' + esc(c.name) + '</button>';
    });
    html += '<button class="chip add" data-act="addCat" data-t="expense">＋ 添加</button></div></div>';

    html += '<div class="sec"><div class="sec-h"><span>收入分类</span><b>' + incCats.length + '</b></div><div class="chips">';
    incCats.forEach(function (c) {
      html += '<button class="chip" data-act="editCat" data-id="' + esc(c.id) + '">' + esc(c.name) + '</button>';
    });
    html += '<button class="chip add" data-act="addCat" data-t="income">＋ 添加</button></div></div>';

    html += '<div class="sec"><div class="sec-h"><span>数据</span><span>' + state.transactions.length + ' 笔记录</span></div>' +
      '<button class="btn" data-act="expCSV">导出 CSV（Excel 可打开）</button>' +
      '<button class="btn" data-act="expJSON">导出完整备份（JSON）</button>' +
      '<button class="btn" data-act="impFile">从文件导入</button>' +
      '<button class="btn" data-act="impPaste">粘贴文本导入</button>' +
      '<button class="btn warn" data-act="clearAll">清空全部数据</button></div>';

    html += '<div class="sec"><div class="sec-h"><span>关于</span><span>v' + APP_VER + '</span></div>' +
      '<div style="font-size:12.5px;line-height:1.8;color:var(--text2)">' +
      '数据只保存在这台手机上，不联网、不上传。<br>' +
      '导入格式：<b>交易时间, 交易类型, 金额, 分类, 账户, 备注</b>，<br>' +
      '交易类型填「支出 / 收入」，金额可为负数，<br>示例：2026-11-03 12:30, 支出, -28.5, 餐饮, 微信零钱, 午饭。' +
      '</div></div>';

    $('meBody').innerHTML = html;
  }

  /* ================= 记一笔 ================= */
  function mostUsedCat(type) {
    var cnt = {}, best = null, bestN = 0;
    state.transactions.forEach(function (t) {
      if (t.type !== type || !t.categoryId) return;
      cnt[t.categoryId] = (cnt[t.categoryId] || 0) + 1;
      if (cnt[t.categoryId] > bestN) { bestN = cnt[t.categoryId]; best = t.categoryId; }
    });
    if (best && C.findById(state.categories, best)) return best;
    var first = state.categories.filter(function (c) { return c.type === type; })[0];
    return first ? first.id : null;
  }

  function openSheet(tx) {
    if (!state.accounts.length) { toast('请先在「我的」里添加一个账户'); return; }
    if (tx) {
      draft = {
        id: tx.id, type: tx.type, amount: C.fmtMoney(tx.amount),
        categoryId: tx.categoryId, accountId: tx.accountId,
        toAccountId: tx.toAccountId, date: C.dayOf(tx.time), note: tx.note || ''
      };
    } else {
      var accId = state.settings.defaultAccountId;
      if (!C.findById(state.accounts, accId)) accId = state.accounts[0].id;
      draft = {
        id: null, type: 'expense', amount: '',
        categoryId: mostUsedCat('expense'), accountId: accId,
        toAccountId: null, date: C.todayStr(), note: ''
      };
    }
    renderSheet();
    $('sheet').classList.remove('hidden');
    $('sheetMask').classList.remove('hidden');
    setTimeout(function () { try { $('fAmount').focus(); } catch (e) { } }, 80);
  }

  function renderSheet() {
    if (!draft) return;
    var segs = $('typeSeg').querySelectorAll('button');
    for (var i = 0; i < segs.length; i++) {
      segs[i].classList.toggle('on', segs[i].getAttribute('data-t') === draft.type);
    }
    $('sheetDelete').classList.toggle('hidden', !draft.id);
    $('gCat').classList.toggle('hidden', draft.type === 'transfer');
    $('gToAcc').classList.toggle('hidden', draft.type !== 'transfer');
    $('gAccLabel').textContent = draft.type === 'transfer' ? '转出账户' : '账户';
    $('fAmount').value = draft.amount || '';
    $('fDate').value = draft.date || C.todayStr();
    $('fNote').value = draft.note || '';

    if (draft.type !== 'transfer') {
      if (!draft.categoryId) draft.categoryId = mostUsedCat(draft.type);
      var cs = state.categories.filter(function (c) { return c.type === draft.type; });
      var h = '';
      cs.forEach(function (c) {
        h += '<button class="chip' + (c.id === draft.categoryId ? ' on' : '') + '" data-act="pickCat" data-id="' + esc(c.id) + '">' +
          iconFor(c.name) + ' ' + esc(c.name) + '</button>';
      });
      h += '<button class="chip add" data-act="addCatQuick">＋ 新分类</button>';
      $('fCats').innerHTML = h;
    }

    var ah = '';
    state.accounts.forEach(function (a) {
      ah += '<button class="chip' + (a.id === draft.accountId ? ' on' : '') + '" data-act="pickAcc" data-id="' + esc(a.id) + '">' + esc(a.name) + '</button>';
    });
    $('fAccs').innerHTML = ah;

    if (draft.type === 'transfer') {
      var th = '';
      state.accounts.forEach(function (a) {
        th += '<button class="chip' + (a.id === draft.toAccountId ? ' on' : '') + '" data-act="pickToAcc" data-id="' + esc(a.id) + '">' + esc(a.name) + '</button>';
      });
      $('fToAccs').innerHTML = th;
    }
  }

  function closeSheet() {
    $('sheet').classList.add('hidden');
    $('sheetMask').classList.add('hidden');
    draft = null;
  }

  function saveTx() {
    if (!draft) return;
    var amount = C.parseAmount($('fAmount').value);
    if (amount === null || amount <= 0) { toast('请输入大于 0 的金额'); return; }
    if (!draft.accountId) { toast('请选择账户'); return; }
    if (draft.type !== 'transfer' && !draft.categoryId) { toast('请选择分类'); return; }
    if (draft.type === 'transfer') {
      if (!draft.toAccountId) { toast('请选择转入账户'); return; }
      if (draft.toAccountId === draft.accountId) { toast('转出和转入不能是同一个账户'); return; }
    }

    var dateVal = $('fDate').value;
    var base = C.normalizeDateTime(dateVal) || (C.todayStr() + ' 00:00:00');
    var dayPart = base.slice(0, 10);
    var hms;
    if (draft.id) {
      var old = C.findById(state.transactions, draft.id);
      hms = old ? String(old.time).slice(11, 19) : C.nowStr().slice(11, 19);
    } else {
      hms = C.nowStr().slice(11, 19);
    }
    if (!/^\d{2}:\d{2}:\d{2}$/.test(hms)) hms = '00:00:00';
    var time = dayPart + ' ' + hms;

    var note = ($('fNote').value || '').trim();
    var isEdit = !!draft.id;

    if (isEdit) {
      var t = C.findById(state.transactions, draft.id);
      if (t) {
        t.type = draft.type;
        t.amount = amount;
        t.time = time;
        t.note = note;
        t.accountId = draft.accountId;
        t.categoryId = draft.type === 'transfer' ? null : draft.categoryId;
        t.toAccountId = draft.type === 'transfer' ? draft.toAccountId : null;
      }
    } else {
      state.transactions.push({
        id: C.uid('tx'),
        type: draft.type,
        time: time,
        amount: amount,
        categoryId: draft.type === 'transfer' ? null : draft.categoryId,
        accountId: draft.accountId,
        toAccountId: draft.type === 'transfer' ? draft.toAccountId : null,
        note: note,
        createdAt: C.nowStr()
      });
    }

    state.settings.defaultAccountId = draft.accountId;
    save();
    listMonth = C.monthOf(time);
    closeSheet();
    toast(isEdit ? '已保存' : '记账成功');
    if (currentView !== 'list') switchView('list'); else renderList();
  }

  function delTx() {
    if (!draft || !draft.id) return;
    var id = draft.id;
    confirmDialog('删除这笔记录', '删除后无法恢复，确定吗？', function () {
      state.transactions = state.transactions.filter(function (t) { return t.id !== id; });
      save();
      closeModal();
      closeSheet();
      toast('已删除');
      renderAll();
    }, '删除');
  }

  /* ================= 账户 / 分类 ================= */
  function typeOptions(sel) {
    var h = '';
    Object.keys(C.ACC_TYPES).forEach(function (k) {
      h += '<option value="' + k + '"' + (k === sel ? ' selected' : '') + '>' + C.ACC_TYPES[k] + '</option>';
    });
    return h;
  }

  function addAcc() {
    openModal({
      title: '添加账户',
      body: '<input id="mName" placeholder="账户名称，如 招商银行">' +
        '<input id="mOpen" inputmode="decimal" placeholder="期初余额（可不填）" style="margin-top:8px">' +
        '<select id="mType" style="margin-top:8px">' + typeOptions('wallet') + '</select>' +
        '<div class="hint">期初余额可以填你现在这个账户里实际有多少钱。</div>',
      focus: 'mName',
      onOk: function () {
        var name = ($('mName').value || '').trim();
        if (!name) { toast('请填写账户名称'); return false; }
        if (C.findByName(state.accounts, name)) { toast('已有同名账户'); return false; }
        var open = C.parseAmount($('mOpen').value);
        state.accounts.push({
          id: C.uid('acc'), name: name,
          type: $('mType').value || 'wallet',
          openingBalance: open === null ? 0 : open
        });
        save(); closeModal(); toast('已添加账户'); renderAll();
      }
    });
  }

  function editAcc(id) {
    var a = C.findById(state.accounts, id);
    if (!a) return;
    var used = state.transactions.filter(function (t) { return t.accountId === id || t.toAccountId === id; }).length;
    openModal({
      title: '编辑账户',
      body: '<input id="mName" value="' + esc(a.name) + '">' +
        '<input id="mOpen" inputmode="decimal" value="' + esc(C.fmtMoney(a.openingBalance)) + '" style="margin-top:8px">' +
        '<select id="mType" style="margin-top:8px">' + typeOptions(a.type) + '</select>' +
        '<div class="hint">期初余额 = 开始记账时该账户已有的钱。<br>这个账户已被 ' + used + ' 笔记录使用。</div>' +
        '<button class="btn warn" data-act="delAcc" data-id="' + esc(id) + '" style="margin-top:12px">删除此账户</button>',
      onOk: function () {
        var name = ($('mName').value || '').trim();
        if (!name) { toast('请填写账户名称'); return false; }
        var dup = C.findByName(state.accounts, name);
        if (dup && dup.id !== id) { toast('已有同名账户'); return false; }
        var open = C.parseAmount($('mOpen').value);
        a.name = name;
        a.type = $('mType').value || a.type;
        a.openingBalance = open === null ? 0 : open;
        save(); closeModal(); toast('已保存'); renderAll();
      }
    });
  }

  function delAcc(id) {
    var used = state.transactions.filter(function (t) { return t.accountId === id || t.toAccountId === id; }).length;
    if (used) { toast('该账户还有 ' + used + ' 笔记录，不能删除'); return; }
    if (state.accounts.length <= 1) { toast('至少保留一个账户'); return; }
    confirmDialog('删除账户', '确定删除这个账户吗？', function () {
      state.accounts = state.accounts.filter(function (a) { return a.id !== id; });
      if (state.settings.defaultAccountId === id) {
        state.settings.defaultAccountId = state.accounts.length ? state.accounts[0].id : null;
      }
      save(); closeModal(); toast('已删除'); renderAll();
    }, '删除');
  }

  function addCat(type) {
    openModal({
      title: type === 'income' ? '添加收入分类' : '添加支出分类',
      body: '<input id="mName" placeholder="分类名称，如 咖啡">',
      focus: 'mName',
      onOk: function () {
        var name = ($('mName').value || '').trim();
        if (!name) { toast('请填写名称'); return false; }
        if (C.findByName(state.categories, name, type)) { toast('已有同名分类'); return false; }
        state.categories.push({ id: C.uid('cat'), name: name, type: type });
        save(); closeModal(); toast('已添加'); renderAll();
      }
    });
  }

  function editCat(id) {
    var c = C.findById(state.categories, id);
    if (!c) return;
    var used = state.transactions.filter(function (t) { return t.categoryId === id; }).length;
    openModal({
      title: '编辑分类',
      body: '<input id="mName" value="' + esc(c.name) + '">' +
        '<div class="hint">已被 ' + used + ' 笔记录使用。</div>' +
        '<button class="btn warn" data-act="delCat" data-id="' + esc(id) + '" style="margin-top:12px">删除此分类</button>',
      onOk: function () {
        var name = ($('mName').value || '').trim();
        if (!name) { toast('请填写名称'); return false; }
        var dup = C.findByName(state.categories, name, c.type);
        if (dup && dup.id !== id) { toast('已有同名分类'); return false; }
        c.name = name;
        save(); closeModal(); toast('已保存'); renderAll();
      }
    });
  }

  function delCat(id) {
    var used = state.transactions.filter(function (t) { return t.categoryId === id; }).length;
    if (used) { toast('该分类还有 ' + used + ' 笔记录，不能删除'); return; }
    confirmDialog('删除分类', '确定删除这个分类吗？', function () {
      state.categories = state.categories.filter(function (c) { return c.id !== id; });
      save(); closeModal(); toast('已删除'); renderAll();
    }, '删除');
  }

  /* ================= 数据 ================= */
  function saveTextFile(name, content) {
    if (Native && typeof Native.saveFile === 'function') {
      try {
        var p = Native.saveFile(name, content);
        if (p) { toast('已保存到 ' + p); return; }
      } catch (e) { }
    }
    try {
      var blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name;
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); if (a.parentNode) a.parentNode.removeChild(a); }, 1500);
      toast('已导出 ' + name);
    } catch (e) {
      toast('导出失败，请改用「粘贴文本导入」里的复制方式');
    }
  }

  function exportCSV() {
    if (!state.transactions.length) { toast('还没有任何记录'); return; }
    saveTextFile('小账本-' + C.todayStr() + '.csv', C.transactionsToCSV(state));
  }

  function exportJSON() {
    saveTextFile('小账本备份-' + C.todayStr() + '.json', JSON.stringify({
      app: 'xiaozhangben', version: 1, exportedAt: C.nowStr(),
      accounts: state.accounts, categories: state.categories,
      transactions: state.transactions, settings: state.settings
    }, null, 1));
  }

  function reportImport(res, isJSON) {
    var msg = '';
    if (isJSON) {
      msg = '已恢复 ' + res.count + ' 笔记录。';
    } else {
      var n = res.created ? res.created.length : 0;
      var errs = res.errors || [];
      msg = '成功导入 ' + n + ' 笔。';
      if (errs.length) msg += '跳过 ' + errs.length + ' 行。';
      if (errs.length) {
        var lines = errs.slice(0, 8).map(function (e) { return '第' + e.line + '行：' + e.reason; }).join('\n');
        msg += '\n\n' + lines + (errs.length > 8 ? '\n…' : '');
      }
    }
    openModal({
      title: '导入结果',
      body: '<div style="white-space:pre-wrap">' + esc(msg) + '</div>',
      okText: '好的'
    });
  }

  function importText(text, fname) {
    text = String(text || '').replace(/^\uFEFF/, '').trim();
    if (!text) { toast('文件内容为空'); return; }
    var first = text.charAt(0);
    if (first === '{' || first === '[') {
      var obj;
      try { obj = JSON.parse(text); } catch (e) { toast('JSON 格式错误'); return; }
      if (Array.isArray(obj)) obj = { transactions: obj };
      if (!obj || !Array.isArray(obj.transactions)) { toast('这不是有效的备份文件'); return; }
      confirmDialog('恢复备份', '将用备份内容覆盖当前全部数据（现有 ' + state.transactions.length + ' 笔记录会被替换），确定吗？', function () {
        state = C.normalizeState(obj);
        save();
        var n = state.transactions.length;
        renderAll();
        openModal({
          title: '导入结果',
          body: '<div>已恢复 ' + n + ' 笔记录。</div>',
          okText: '好的'
        });
        toast('已恢复备份');
        return false;
      }, '覆盖恢复');
      return;
    }
    var res = C.importCSV(text, state);
    if (res.created && res.created.length) {
      save();
      renderAll();
    }
    reportImport(res, false);
  }

  function importFile() {
    var input = $('fileInput');
    input.value = '';
    input.onchange = function () {
      var f = input.files && input.files[0];
      if (!f) return;
      var reader = new FileReader();
      reader.onload = function () { importText(reader.result, f.name); };
      reader.onerror = function () { toast('读取文件失败'); };
      reader.readAsText(f, 'utf-8');
    };
    input.click();
  }

  function importPaste() {
    openModal({
      title: '粘贴文本导入',
      body: '<textarea id="mPaste" placeholder="把 CSV 内容粘贴到这里，第一行是表头：&#10;交易时间,交易类型,金额,分类,账户,备注&#10;2026-11-03 12:30,支出,-28.5,餐饮,微信零钱,午饭"></textarea>' +
        '<div class="hint">支持从 Excel / 公众号账单 / 其他记账软件复制的文本。可自动识别 <b>时间、类型、金额、分类、账户、备注</b> 这些列，缺失的分类和账户会自动创建。</div>',
      onOk: function () {
        var t = $('mPaste').value;
        if (!t || !t.trim()) { toast('请先粘贴内容'); return false; }
        importText(t);
        return false;
      }
    });
  }

  function clearAll() {
    confirmDialog('清空全部数据', '所有账户、分类和 ' + state.transactions.length + ' 笔记录都会被删除，且无法恢复。建议先导出备份。', function () {
      state = C.defaultState();
      save();
      closeModal();
      listMonth = C.monthOf(C.nowStr());
      toast('已清空');
      renderAll();
    }, '确认清空');
  }

  /* ================= 事件 ================= */
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.closest) return;

    var actEl = t.closest('[data-act]');
    if (actEl) {
      var act = actEl.getAttribute('data-act');
      var id = actEl.getAttribute('data-id');
      switch (act) {
        case 'tab': switchView(actEl.getAttribute('data-view')); return;
        case 'add': openSheet(null); return;
        case 'today':
          listMonth = C.monthOf(C.nowStr());
          if (currentView !== 'list') switchView('list'); else renderList();
          return;
        case 'prevMonth': listMonth = C.shiftMonth(listMonth, -1); renderAll(); return;
        case 'nextMonth': listMonth = C.shiftMonth(listMonth, 1); renderAll(); return;
        case 'closeSheet': closeSheet(); return;
        case 'saveTx': saveTx(); return;
        case 'delTx': delTx(); return;
        case 'setType':
          if (!draft) return;
          draft.type = actEl.getAttribute('data-t');
          if (draft.type === 'transfer') {
            draft.categoryId = null;
            if (draft.toAccountId === draft.accountId) draft.toAccountId = null;
          } else {
            draft.categoryId = mostUsedCat(draft.type);
          }
          renderSheet(); return;
        case 'pickCat':
          if (draft) { draft.categoryId = id; renderSheet(); }
          return;
        case 'pickAcc':
          if (draft) { draft.accountId = id; renderSheet(); }
          return;
        case 'pickToAcc':
          if (draft) { draft.toAccountId = id; renderSheet(); }
          return;
        case 'addCatQuick':
          if (!draft) return;
          addCat(draft.type);
          return;
        case 'addAcc': addAcc(); return;
        case 'editAcc': editAcc(id); return;
        case 'delAcc': delAcc(id); return;
        case 'addCat': addCat(actEl.getAttribute('data-t') || 'expense'); return;
        case 'editCat': editCat(id); return;
        case 'delCat': delCat(id); return;
        case 'expCSV': exportCSV(); return;
        case 'expJSON': exportJSON(); return;
        case 'impFile': importFile(); return;
        case 'impPaste': importPaste(); return;
        case 'clearAll': clearAll(); return;
        case 'modalCancel': closeModal(); return;
        case 'modalOk':
          var r = modalOnOk ? modalOnOk() : undefined;
          if (r !== false) closeModal();
          return;
      }
      return;
    }

    var txEl = t.closest('.tx');
    if (txEl && txEl.getAttribute('data-id')) {
      var tx = C.findById(state.transactions, txEl.getAttribute('data-id'));
      if (tx) openSheet(tx);
    }
  });

  window.__errCount = 0;
  window.addEventListener('error', function (ev) {
    if (window.__errCount >= 3) return;
    window.__errCount++;
    var m = ev && ev.message ? ev.message : '未知错误';
    toast('脚本异常：' + m);
  });

  /* ================= 启动 ================= */
  function boot() {
    state = loadState();
    save();
    switchView('list');
    if (!state.transactions.length) {
      setTimeout(function () { toast('点右下角「＋」记第一笔'); }, 700);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
