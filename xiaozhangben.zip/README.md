# 小账本（xiaozhangben）

一个**纯离线、不联网、数据只存在你手机里**的记账 App。界面模仿 ezBookkeeping 的手机端，但做成了一个可以直接安装的 APK。

- 记支出 / 收入 / 转账，按月按日看明细
- 统计页：支出分类排行、近 6 个月收支柱状图、收入构成
- 多账户（现金/微信/支付宝/银行卡/信用卡/投资），账户余额自动算
- 分类可增删改，被引用时禁止删除
- CSV 导出 / 导入（列和「小乖记账」那类软件的表能对上）、JSON 整库备份恢复、粘贴文本导入
- 深色模式跟随系统、底部安全区适配
- **没有任何第三方依赖**：纯 Java（一个 WebView 壳）+ 内置 HTML/CSS/JS

---

## 怎么拿到 APK（不需要装任何开发工具）

本机没有 JDK / Android SDK / Gradle，也连不上外网，所以**编译交给 GitHub 的免费服务器做**。你只要把下面这个文件夹传到 GitHub。

### 第 1 步：建一个仓库

1. 打开 https://github.com ，登录（没账号就注册一个）
2. 右上角 `+` → **New repository**
3. Repository name 填 `xiaozhangben`
4. 选 **Public**（推荐：公共仓库的 Actions 构建完全免费、手机上下载 APK 不用登录；选 Private 也行，但下载 Release 时要登录）
5. 不要勾选 "Add a README file"，直接点 **Create repository**

### 第 2 步：把代码传上去（zip 方式）

GitHub 网页的上传**不支持拖文件夹**（会报 `Something went really wrong`），所以走 zip：

1. 打开 `https://github.com/<你的用户名>/xiaozhangben/upload/main`
2. 点 **choose your files**，只选中上级目录里的 **`xiaozhangben.zip`** 这一个文件
3. 页面最下面点 **Commit changes**

构建脚本会自动把 zip 解开再编译，不需要解压上传。

### 第 2.5 步：补上构建脚本

仓库页面点 `Add file` → `Create new file`，文件名框输入：

```
.github/workflows/build.yml
```

（输入 `/` 会自动建目录）然后把 `workflow-spare-build.yml` 的全部内容粘进去 → **Commit changes**。

这一提交会自动开始构建。以后改了代码，只要重新传一次新 zip 覆盖，脚本不用再动。

> 如果你以后想在电脑上正常上传整个目录（而不是 zip），脚本同样支持：只要仓库根目录有 `app/build.gradle`，它会直接按目录结构编译。

### 第 3 步：等 2~4 分钟，下载 APK

1. 点仓库顶部的 **Actions** 标签
2. 会看到一条正在跑的 `Build APK`（黄点=进行中，绿勾=成功，红叉=失败）
3. 绿勾后点进去，页面最下方 **Artifacts** → 下载 `xiaozhangben-apk`（是个 zip，解压里面有 `xiaozhangben.apk`）
4. 或者更省事：点仓库右侧 **Releases**，里面有一个 `小账本 v1.0.x`，直接下载 `xiaozhangben.apk`

### 第 4 步：装到手机上

把 `xiaozhangben.apk` 发到手机（微信传文件 / QQ / 数据线 / 网盘都行），点开安装。第一次会提示「不允许安装未知应用」，按提示允许即可。

> 这是 Debug 签名包，自己用完全没问题。以后我改了代码，你重新传一次 GitHub，会出新版本，**直接覆盖安装**即可，账本数据不会丢。

---

## 手机上怎么用

- 右下角 `＋` 记一笔；点列表里任意一条可以改金额、分类、账户、备注，或删除
- 顶部左右箭头翻月份，中间的月份点一下回到本月
- `我的` 页里管理账户和分类，以及导出/导入

## 数据安全

数据存在 App 私有目录（`/data/data/com.ezmobile.app/files/xiaozhangben-data.json`），**不联网、不上传、不收集任何信息**。但：

- **卸载 App 会一起删掉数据**
- 换手机不会自动迁移

所以建议每隔一阵去 `我的` → `导出 JSON 备份`，把文件存到网盘或发给自己。要恢复就 `导入文件` 选那个 json。

## 从「小乖记账」搬账

1. 在「小乖记账」里按月截图（要能看清日期、分类、金额、账户、备注）
2. 把截图发我，我 OCR 成 CSV：`交易时间,交易类型,金额,分类,账户,备注`
3. 在小账本里 `我的` → `粘贴文本导入`（或 `导入文件` 选 csv），缺的分类和账户会自动创建

## 开发者备注

```
app/src/main/assets/   ← 全部界面与业务逻辑（改这里就行，不用碰 Java）
  core.js   纯函数逻辑层（Node 可直接跑）
  app.js    界面渲染 + 事件
  app.css   样式
  index.html
app/src/main/java/com/ezmobile/app/MainActivity.java  ← WebView 壳 + 数据落盘 + 剪贴板
tests/      本地测试（node tests/core.test.js 等三个脚本，共 108 项）
```

改完本地验证（本机可用 DSH 自带 Node）：

```powershell
$node = "C:\Users\123\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
& $node tests\core.test.js
& $node tests\dom.check.js
& $node tests\ui.test.js
```

三个都通过再传 GitHub。
