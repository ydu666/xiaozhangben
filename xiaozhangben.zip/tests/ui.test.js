/* 用最小 DOM 桩把 app.js 真正跑起来，做端到端行为测试 */
const assert = require('assert');

/* ---------- 最小 DOM ---------- */
function makeEl(id) {
  const attrs = {};
  const el = {
    id,
    value: '',
    textContent: '',
    className: '',
    files: null,
    style: {},
    _html: '',
    parentNode: null,
    attrs,
    get innerHTML() { return el._html; },
    set innerHTML(v) { el._html = String(v); },
    classList: {
      _s: new Set(),
      add(c) { this._s.add(c); },
      remove(c) { this._s.delete(c); },
      contains(c) { return this._s.has(c); },
      toggle(c, f) { if (f === undefined) { this._s.has(c) ? this._s.delete(c) : this._s.add(c); } else if (f) this._s.add(c); else this._s.delete(c); }
    },
    getAttribute(k) { return k in attrs ? attrs[k] : null; },
    setAttribute(k, v) { attrs[k] = String(v); },
    removeAttribute(k) { delete attrs[k]; },
    addEventListener() { },
    removeEventListener() { },
    appendChild(c) { c.parentNode = el; return c; },
    removeChild(c) { return c; },
    focus() { },
    click() { },
    closest(sel) {
      if (sel === '[data-act]') return attrs['data-act'] ? el : null;
      if (sel === '.tx') return attrs['data-id'] && attrs['data-act'] === undefined ? el : null;
      return null;
    },
    querySelector() { return null; },
    querySelectorAll() { return []; }
  };
  return el;
}

const els = new Map();
function getEl(id) {
  if (!els.has(id)) els.set(id, makeEl(id));
  return els.get(id);
}

/* 让 tabbar / typeSeg 的 querySelectorAll 返回可用的子元素 */
const tabStub = ['list', 'stats', 'me'].map(v => { const e = makeEl('tab-' + v); e.setAttribute('data-view', v); return e; });
els.set('tabbar', Object.assign(makeEl('tabbar'), { querySelectorAll: () => tabStub }));
const segStub = ['expense', 'income', 'transfer'].map(v => { const e = makeEl('seg-' + v); e.setAttribute('data-t', v); return e; });
els.set('typeSeg', Object.assign(makeEl('typeSeg'), { querySelectorAll: () => segStub }));

/* ---------- 存储桩 ---------- */
const store = new Map();
global.localStorage = {
  getItem: k => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => { store.set(k, String(v)); },
  removeItem: k => { store.delete(k); }
};

/* ---------- 其它全局 ---------- */
let clickHandler = null;
global.document = {
  readyState: 'complete',
  body: makeEl('body'),
  getElementById: getEl,
  createElement: tag => makeEl('created-' + tag),
  addEventListener: (ev, fn) => { if (ev === 'click') clickHandler = fn; }
};
global.window = global;
global.addEventListener = () => { };
global.removeEventListener = () => { };
global.URL = { createObjectURL: () => 'blob:fake', revokeObjectURL: () => { } };
global.FileReader = class { readAsText() { } };
if (typeof global.Blob === 'undefined') global.Blob = class { constructor(p) { this.parts = p; } };

function click(attrs) {
  const el = makeEl('click-' + (attrs['data-act'] || attrs['data-id']));
  Object.keys(attrs).forEach(k => el.setAttribute(k, attrs[k]));
  clickHandler({ target: el });
}
function stateNow() {
  return JSON.parse(store.get('xiaozhangben.v1'));
}

/* ---------- 跑起来 ---------- */
require('../app/src/main/assets/core.js');
require('../app/src/main/assets/app.js');

let pass = 0;
function ok(name, fn) { fn(); pass++; console.log('  ok  ' + name); }

console.log('--- 启动 ---');
ok('boot 不抛异常且已落盘', () => assert.ok(store.has('xiaozhangben.v1')));
ok('默认 4 个账户 / 14 个分类', () => {
  const s = stateNow();
  assert.strictEqual(s.accounts.length, 4);
  assert.strictEqual(s.categories.length, 14);
});
ok('明细页渲染出空状态', () => assert.ok(/还没有记录/.test(getEl('txList').innerHTML)));
ok('月份标题已填充', () => assert.ok(/\d{4}年\d{1,2}月/.test(getEl('monthLabel').textContent)));

console.log('--- 记一笔：支出 ---');
click({ 'data-act': 'add' });
getEl('fAmount').value = '28.5';
getEl('fDate').value = '2026-11-03';
getEl('fNote').value = '午饭';
click({ 'data-act': 'saveTx' });

ok('落盘 1 笔', () => assert.strictEqual(stateNow().transactions.length, 1));
ok('金额与备注正确', () => {
  const t = stateNow().transactions[0];
  assert.strictEqual(t.amount, 28.5);
  assert.strictEqual(t.note, '午饭');
  assert.strictEqual(t.type, 'expense');
  assert.ok(t.time.startsWith('2026-11-03 '), '时间=' + t.time);
});
ok('列表出现这一笔', () => assert.ok(/午饭/.test(getEl('txList').innerHTML)));
ok('月支出汇总 = 28.50', () => assert.strictEqual(getEl('sumExpense').textContent, '28.50'));

console.log('--- 记一笔：收入 ---');
click({ 'data-act': 'add' });
click({ 'data-act': 'setType', 'data-t': 'income' });
getEl('fAmount').value = '8000';
getEl('fDate').value = '2026-11-05';
click({ 'data-act': 'saveTx' });
ok('落盘 2 笔', () => assert.strictEqual(stateNow().transactions.length, 2));
ok('收入汇总 = 8,000.00', () => assert.strictEqual(getEl('sumIncome').textContent, '8,000.00'));
ok('结余 = 7,971.50', () => assert.strictEqual(getEl('sumNet').textContent, '7,971.50'));

console.log('--- 校验拦截 ---');
click({ 'data-act': 'add' });
getEl('fAmount').value = '';
click({ 'data-act': 'saveTx' });
ok('空金额被拦截，仍是 2 笔', () => assert.strictEqual(stateNow().transactions.length, 2));
getEl('fAmount').value = '12';
click({ 'data-act': 'setType', 'data-t': 'transfer' });
click({ 'data-act': 'saveTx' });
ok('转账未选转入账户被拦截', () => assert.strictEqual(stateNow().transactions.length, 2));
click({ 'data-act': 'closeSheet' });

console.log('--- 切换视图 ---');
click({ 'data-act': 'tab', 'data-view': 'stats' });
ok('统计页有内容', () => assert.ok(getEl('statsBody').innerHTML.length > 200));
ok('统计含支出构成', () => assert.ok(/支出构成/.test(getEl('statsBody').innerHTML)));
ok('统计含近 6 个月', () => assert.ok(/近 6 个月/.test(getEl('statsBody').innerHTML)));
click({ 'data-act': 'tab', 'data-view': 'me' });
ok('我的页有账户', () => assert.ok(/微信零钱/.test(getEl('meBody').innerHTML)));
ok('我的页有资产总计', () => assert.ok(/资产总计|我的账户/.test(getEl('meBody').innerHTML)));

console.log('--- 翻月 ---');
click({ 'data-act': 'tab', 'data-view': 'list' });
click({ 'data-act': 'prevMonth' });
ok('回到上一月显示空', () => assert.ok(/还没有记录/.test(getEl('txList').innerHTML)));
click({ 'data-act': 'nextMonth' });
ok('再回来有记录', () => assert.ok(/午饭/.test(getEl('txList').innerHTML)));

console.log('--- 粘贴导入 ---');
const csv =
  '交易时间,交易类型,金额,分类,账户,备注\n' +
  '2026-11-06 08:00:00,支出,-4.5,餐饮,微信零钱,豆浆\n' +
  '2026-11-07 19:00:00,支出,-88,购物,支付宝,袜子\n' +
  '坏行,支出,xx,餐饮,,坏\n';
click({ 'data-act': 'impPaste' });
getEl('mPaste').value = csv;
click({ 'data-act': 'modalOk' });
ok('导入成功后共 4 笔', () => assert.strictEqual(stateNow().transactions.length, 4));
ok('报告弹窗出现', () => assert.ok(/导入结果/.test(getEl('modalTitle').textContent)));
ok('报告提示跳过 1 行', () => assert.ok(/跳过 1 行/.test(getEl('modalBody').innerHTML)));
click({ 'data-act': 'modalOk' });
ok('弹窗可关闭', () => assert.ok(getEl('modal').classList.contains('hidden')));

console.log('--- 编辑已有记录 ---');
const target = stateNow().transactions.find(t => t.note === '豆浆');
click({ 'data-id': target.id });
ok('点条目打开面板', () => assert.ok(!getEl('sheet').classList.contains('hidden')));
getEl('fAmount').value = '6';
click({ 'data-act': 'saveTx' });
ok('修改后金额变为 6', () => {
  const t = stateNow().transactions.find(x => x.id === target.id);
  assert.strictEqual(t.amount, 6);
  assert.strictEqual(stateNow().transactions.length, 4);
});

console.log('--- 新增账户 / 分类 ---');
click({ 'data-act': 'tab', 'data-view': 'me' });
click({ 'data-act': 'addAcc' });
getEl('mName').value = '招商银行';
getEl('mOpen').value = '1000';
click({ 'data-act': 'modalOk' });
ok('账户数变为 5', () => assert.strictEqual(stateNow().accounts.length, 5));
ok('期初余额已保存', () => assert.strictEqual(stateNow().accounts[4].openingBalance, 1000));
click({ 'data-act': 'addCat', 'data-t': 'expense' });
getEl('mName').value = '宠物';
click({ 'data-act': 'modalOk' });
ok('分类数变为 15', () => assert.strictEqual(stateNow().categories.length, 15));

console.log('--- 导出 ---');
click({ 'data-act': 'expCSV' });
ok('导出 CSV 不抛异常', () => assert.ok(true));
click({ 'data-act': 'expJSON' });
ok('导出 JSON 不抛异常', () => assert.ok(true));

console.log('--- 清空 ---');
click({ 'data-act': 'clearAll' });
click({ 'data-act': 'modalOk' });
ok('清空后 0 笔', () => assert.strictEqual(stateNow().transactions.length, 0));

console.log('\n全部通过：' + pass + ' 项');
