/* 静态检查：app.js 里用到的元素 id 必须都在 index.html 中存在 */
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', 'app', 'src', 'main', 'assets');
const html = fs.readFileSync(path.join(dir, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(dir, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(dir, 'app.css'), 'utf8');

const htmlIds = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
const jsIds = new Set([...js.matchAll(/\bid="([A-Za-z0-9_-]+)"/g)].map(m => m[1]));

const used = new Set([...js.matchAll(/\$\('([A-Za-z0-9_-]+)'\)/g)].map(m => m[1]));

const missing = [...used].filter(id => !htmlIds.has(id) && !jsIds.has(id));
const unused = [...htmlIds].filter(id => !used.has(id));

console.log('index.html 中的 id：' + htmlIds.size + ' 个');
console.log('app.js 引用的 id：' + used.size + ' 个');
if (missing.length) {
  console.log('\n❌ 引用了但 HTML 中不存在：');
  missing.forEach(id => console.log('   - ' + id));
} else {
  console.log('✅ 所有引用的 id 都存在');
}
if (unused.length) console.log('\n（HTML 中定义但 JS 未用到：' + unused.join(', ') + '）');

/* data-act 覆盖检查 */
const htmlActs = new Set([...html.matchAll(/data-act="([a-zA-Z]+)"/g)].map(m => m[1]));
const jsActs = new Set([...js.matchAll(/data-act=\\?"([a-zA-Z]+)\\?"/g)].map(m => m[1]));
const allActs = new Set([...htmlActs, ...jsActs]);
const handled = new Set([...js.matchAll(/case '([a-zA-Z]+)':/g)].map(m => m[1]));
const unhandled = [...allActs].filter(a => !handled.has(a));
const deadCases = [...handled].filter(a => !allActs.has(a));
console.log('\ndata-act 共 ' + allActs.size + ' 种，switch 里处理了 ' + handled.size + ' 种');
if (unhandled.length) console.log('❌ 有按钮但没处理：' + unhandled.join(', '));
else console.log('✅ 所有 data-act 都有对应处理');
if (deadCases.length) console.log('⚠ 有 case 但没有按钮触发（可能是动态生成）：' + deadCases.join(', '));

/* CSS 基本配对检查 */
const open = (css.match(/{/g) || []).length;
const close = (css.match(/}/g) || []).length;
console.log('\nCSS 花括号：' + open + ' 开 / ' + close + ' 闭' + (open === close ? ' ✅' : ' ❌'));

/* JS 里用到的 class 是否在 CSS 中出现（只报完全没定义的自定义类） */
const jsClasses = new Set();
for (const m of js.matchAll(/\bclass="([a-z0-9 _-]+)"/g)) {
  m[1].split(/\s+/).filter(Boolean).forEach(c => jsClasses.add(c));
}
const cssClasses = new Set([...css.matchAll(/\.([a-zA-Z][\w-]*)/g)].map(m => m[1]));
const typo = [...jsClasses].filter(c => !cssClasses.has(c));
console.log('JS 生成的元素 class 共 ' + jsClasses.size + ' 个；CSS 未定义的：' + (typo.length ? typo.join(', ') : '无 ✅'));

if (missing.length) process.exit(1);
