/* 用本机 Node 直接跑： node tests/core.test.js */
const assert = require('assert');
const C = require('../app/src/main/assets/core.js');

let pass = 0;
function ok(name, fn) { fn(); pass++; console.log('  ok  ' + name); }

console.log('--- normalizeDateTime ---');
ok('标准格式', () => assert.strictEqual(C.normalizeDateTime('2024-01-02 03:04:05'), '2024-01-02 03:04:05'));
ok('斜杠+无秒', () => assert.strictEqual(C.normalizeDateTime('2024/1/2 3:04'), '2024-01-02 03:04:00'));
ok('ISO T 毫秒 Z', () => assert.strictEqual(C.normalizeDateTime('2024-01-02T03:04:05.123Z'), '2024-01-02 03:04:05'));
ok('带时区偏移', () => assert.strictEqual(C.normalizeDateTime('2024-01-02T03:04:05+08:00'), '2024-01-02 03:04:05'));
ok('中文年月日', () => assert.strictEqual(C.normalizeDateTime('2024年1月2日 03:04'), '2024-01-02 03:04:00'));
ok('只有日期', () => assert.strictEqual(C.normalizeDateTime('2024-01-02'), '2024-01-02 00:00:00'));
ok('空值', () => assert.strictEqual(C.normalizeDateTime(''), null));
ok('乱码', () => assert.strictEqual(C.normalizeDateTime('abc'), null));
ok('非法月份', () => assert.strictEqual(C.normalizeDateTime('2024-13-01'), null));

console.log('--- parseAmount ---');
ok('普通', () => assert.strictEqual(C.parseAmount('123.45'), 123.45));
ok('带符号与逗号', () => assert.strictEqual(C.parseAmount('¥ -1,234.50'), -1234.5));
ok('带元', () => assert.strictEqual(C.parseAmount('88元'), 88));
ok('空', () => assert.strictEqual(C.parseAmount(''), null));

console.log('--- shiftMonth ---');
ok('跨年回退', () => assert.strictEqual(C.shiftMonth('2024-01', -1), '2023-12'));
ok('跨年前进', () => assert.strictEqual(C.shiftMonth('2024-12', 1), '2025-01'));
ok('多月回退', () => assert.strictEqual(C.shiftMonth('2024-03', -14), '2023-01'));

console.log('--- 账目计算 ---');
const st = C.defaultState();
const acc = st.accounts[1];
st.settings.defaultAccountId = acc.id;
ok('初始余额 0', () => assert.strictEqual(C.accountBalance(st, acc.id), 0));

C.importCSV(
  '交易时间,交易类型,金额,分类,账户,备注\n' +
  '2024-01-05 10:00:00,支出,-30.50,餐饮,微信零钱,午饭\n' +
  '2024-01-06 09:00:00,收入,8000,工资,微信零钱,发薪\n' +
  '2024-01-07 12:00:00,支出,-19.90,交通,现金,打车\n',
  st
);
ok('导入 3 条', () => assert.strictEqual(st.transactions.length, 3));
ok('余额 7969.50（打车走现金，不影响微信）', () => assert.strictEqual(C.accountBalance(st, acc.id), 7969.5));

const s1 = C.monthSummary(st, '2024-01');
ok('月支出 50.40', () => assert.strictEqual(s1.expense, 50.4));
ok('月收入 8000', () => assert.strictEqual(s1.income, 8000));
ok('月结余 7949.60', () => assert.strictEqual(s1.net, 7949.6));
ok('笔数 3', () => assert.strictEqual(s1.count, 3));

const g = C.groupByDay(C.monthTransactions(st, '2024-01'));
ok('分组 3 天', () => assert.strictEqual(g.length, 3));

const ct = C.categoryTotals(st, '2024-01', 'expense');
ok('支出分类首位是餐饮 30.50', () => { assert.strictEqual(ct[0].name, '餐饮'); assert.strictEqual(ct[0].amount, 30.5); });

const tr = C.monthlyTrend(st, '2024-02', 3);
ok('趋势 3 个月且升序', () => {
  assert.deepStrictEqual(tr.map(x => x.month), ['2023-12', '2024-01', '2024-02']);
  assert.strictEqual(tr[1].expense, 50.4);
});

console.log('--- 转账 ---');
const st2 = C.defaultState();
const a1 = st2.accounts[0].id, a2 = st2.accounts[3].id;
st2.transactions.push({ id: 'x', type: 'transfer', time: '2024-02-01 00:00:00', amount: 100, accountId: a1, toAccountId: a2, categoryId: null, note: '' });
ok('转出 -100', () => assert.strictEqual(C.accountBalance(st2, a1), -100));
ok('转入 +100', () => assert.strictEqual(C.accountBalance(st2, a2), 100));
ok('转账不计入收支', () => assert.strictEqual(C.monthSummary(st2, '2024-02').expense, 0));

console.log('--- CSV 往返 ---');
const csv = C.transactionsToCSV(st);
const st3 = C.defaultState();
const res = C.importCSV(csv, st3);
ok('往返条数一致', () => assert.strictEqual(res.created.length, 3));
ok('往返无错误', () => assert.deepStrictEqual(res.errors, []));
ok('往返金额一致', () => {
  const sum = st3.transactions.reduce((s, t) => s + (t.type === 'expense' ? -t.amount : t.amount), 0);
  assert.strictEqual(Math.round(sum * 100) / 100, 7949.6);
});
ok('往返日期一致', () => {
  const t = st3.transactions.find(x => x.note === '午饭');
  assert.strictEqual(t.time, '2024-01-05 10:00:00');
});

console.log('--- CSV 解析边界 ---');
ok('引号内逗号与换行', () => {
  const rows = C.parseCSV('a,b\n"x,1","y\n2"\n');
  assert.deepStrictEqual(rows, [['a', 'b'], ['x,1', 'y\n2']]);
});
ok('转义双引号', () => {
  const rows = C.parseCSV('"a""b",c');
  assert.deepStrictEqual(rows, [['a"b', 'c']]);
});
ok('BOM 与 CRLF', () => {
  const rows = C.parseCSV('\uFEFFa,b\r\n1,2\r\n');
  assert.deepStrictEqual(rows, [['a', 'b'], ['1', '2']]);
});

console.log('--- 导入容错 ---');
const bad = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n不是日期,支出,10,餐饮,,x\n2024-03-01,支出,加哦,餐饮,,x\n2024-03-02,转账,50,,,\n', C.defaultState());
ok('坏行进 errors 不中断', () => {
  assert.strictEqual(bad.created.length, 0);
  assert.strictEqual(bad.errors.length, 3);
});
ok('缺表头报错', () => {
  const r = C.importCSV('123\n456\n', C.defaultState());
  assert.strictEqual(r.created.length, 0);
  assert.ok(/表头/.test(r.errors[0].reason));
});
ok('自动建分类', () => {
  const s = C.defaultState();
  const r = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-03-01 08:00:00,支出,-5,咖啡,,x\n', s);
  assert.strictEqual(r.created.length, 1);
  assert.ok(C.findByName(s.categories, '咖啡', 'expense'));
});
ok('自动建账户', () => {
  const s = C.defaultState();
  const r = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-03-01 08:00:00,支出,-5,餐饮,新银行卡,x\n', s);
  assert.strictEqual(r.created.length, 1);
  assert.ok(C.findByName(s.accounts, '新银行卡'));
});
ok('负数金额按支出', () => {
  const s = C.defaultState();
  const r = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-03-01,,-9.9,餐饮,,x\n', s);
  assert.strictEqual(r.created[0].type, 'expense');
  assert.strictEqual(r.created[0].amount, 9.9);
});
ok('正数金额无类型按收入', () => {
  const s = C.defaultState();
  const r = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-03-01,,9.9,工资,,x\n', s);
  assert.strictEqual(r.created[0].type, 'income');
});

console.log('--- 区间汇总 / 数据总览 ---');
const ov = C.defaultState();
C.importCSV(
  '交易时间,交易类型,金额,分类,账户,备注\n' +
  '2024-01-05 10:00:00,支出,-30.50,餐饮,微信零钱,午饭\n' +
  '2024-01-06 09:00:00,收入,8000,工资,微信零钱,发薪\n' +
  '2024-01-31 20:00:00,支出,-1200,购物,微信零钱,耳机\n' +
  '2024-02-02 08:00:00,支出,-20,餐饮,现金,早餐\n', ov);
ok('月度总览收入/支出/结余', () => {
  const o = C.overview(ov, 'month', '2024-01');
  assert.strictEqual(o.expense, 1230.5);
  assert.strictEqual(o.income, 8000);
  assert.strictEqual(o.net, 6769.5);
  assert.strictEqual(o.count, 3);
  assert.strictEqual(o.activeDays, 3);
  assert.strictEqual(o.calendarDays, 31);
  assert.strictEqual(o.maxAmount, 1200);
});
ok('日均支出 = 支出/当月天数', () => assert.strictEqual(C.overview(ov, 'month', '2024-01').avgPerDay, 39.69));
ok('年度总览跨月合并', () => {
  const o = C.overview(ov, 'year', '2024');
  assert.strictEqual(o.count, 4);
  assert.strictEqual(o.expense, 1250.5);
  assert.strictEqual(o.from, '2024-01');
  assert.strictEqual(o.to, '2024-12');
  assert.strictEqual(o.calendarDays, 366);
});
ok('日序列 31 条且按日汇总', () => {
  const s = C.daySeries(ov, '2024-01');
  assert.strictEqual(s.length, 31);
  assert.strictEqual(s[4].key, '05');
  assert.strictEqual(s[4].expense, 30.5);
  assert.strictEqual(s[30].expense, 1200);
});
ok('年序列 12 条', () => {
  const y = C.yearSeries(ov, '2024');
  assert.strictEqual(y.length, 12);
  assert.strictEqual(y[0].label, '1月');
  assert.strictEqual(y[0].expense, 1230.5);
  assert.strictEqual(y[0].income, 8000);
  assert.strictEqual(y[1].expense, 20);
});
ok('区间分类合计', () => {
  const c = C.categoryTotalsBetween(ov, '2024-01', '2024-02', 'expense');
  assert.strictEqual(c.length, 2);
  assert.strictEqual(c[0].name, '购物');
  assert.strictEqual(c[0].amount, 1200);
});

console.log('--- 预算 ---');
const bst = C.defaultState();
C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-01-05 10:00:00,支出,-300,餐饮,现金,x\n', bst);
ok('未设预算 has=false', () => assert.strictEqual(C.budgetStatus(bst, '2024-01').has, false));
ok('设置预算', () => { C.setBudget(bst, '2024-01', 1000); assert.strictEqual(C.budgetOf(bst, '2024-01'), 1000); });
ok('预算状态：已花/剩余/百分比', () => {
  const b = C.budgetStatus(bst, '2024-01');
  assert.strictEqual(b.has, true);
  assert.strictEqual(b.spent, 300);
  assert.strictEqual(b.left, 700);
  assert.strictEqual(b.over, false);
  assert.strictEqual(b.percent, 30);
});
ok('超支判定', () => {
  C.setBudget(bst, '2024-01', 200);
  const b = C.budgetStatus(bst, '2024-01');
  assert.strictEqual(b.over, true);
  assert.strictEqual(b.left, -100);
});
ok('填 0 删除预算', () => {
  C.setBudget(bst, '2024-01', 0);
  assert.strictEqual(bst.settings.budgets['2024-01'], undefined);
  assert.strictEqual(C.budgetStatus(bst, '2024-01').has, false);
});

console.log('--- 大件 ---');
const bigs = [
  { id: 'b1', name: '手表', price: 50000, cat: '手表', status: 'bought', date: '2024-01-01' },
  { id: 'b2', name: '相机', price: 12000, cat: '数码', status: 'want', date: '2024-02-01' },
  { id: 'b3', name: '戒指', price: 8000, cat: '珠宝', status: 'want', date: '2024-03-01' }
];
ok('大件统计', () => {
  const s = C.bigItemStats(bigs);
  assert.strictEqual(s.count, 3);
  assert.strictEqual(s.boughtCount, 1);
  assert.strictEqual(s.wantCount, 2);
  assert.strictEqual(s.boughtTotal, 50000);
  assert.strictEqual(s.wantTotal, 20000);
  assert.strictEqual(s.max, 50000);
  assert.strictEqual(s.maxName, '手表');
});
ok('大件空列表不报错', () => {
  const s = C.bigItemStats([]);
  assert.strictEqual(s.count, 0);
  assert.strictEqual(s.max, 0);
  assert.strictEqual(s.maxName, '');
});
ok('normalizeState 补全大件与预算', () => {
  const s = C.normalizeState({ bigItems: [{ name: '包', price: '3000' }], settings: { budgets: { '2024-05': '1200' } } });
  assert.strictEqual(s.bigItems.length, 1);
  assert.strictEqual(s.bigItems[0].price, 3000);
  assert.strictEqual(s.bigItems[0].status, 'want');
  assert.strictEqual(s.bigItems[0].cat, '其他');
  assert.strictEqual(s.settings.budgets['2024-05'], 1200);
});

console.log('--- 二级分类与记账天数 ---');
function catName(s, t) {
  const c = s.categories.find(function (x) { return x.id === t.categoryId; });
  return c ? c.name : '';
}
ok('splitCategory 拆斜杠', () => {
  const p = C.splitCategory('餐饮/早餐');
  assert.strictEqual(p.parent, '餐饮');
  assert.strictEqual(p.child, '早餐');
});
ok('splitCategory 拆箭头与大于号', () => {
  assert.strictEqual(C.splitCategory('购物 > 衣服').child, '衣服');
  assert.strictEqual(C.splitCategory('交通→打车').parent, '交通');
});
ok('splitCategory 无分隔符只有一级', () => {
  const p = C.splitCategory('人情');
  assert.strictEqual(p.parent, '人情');
  assert.strictEqual(p.child, '');
});
ok('joinCategory 组装', () => {
  assert.strictEqual(C.joinCategory('餐饮', '早餐'), '餐饮/早餐');
  assert.strictEqual(C.joinCategory('餐饮', ''), '餐饮');
});
ok('导入两列分类：一级+二级', () => {
  const s = C.defaultState();
  C.importCSV('交易时间,交易类型,金额,一级分类,二级分类,账户,备注\n2024-01-05 08:00:00,支出,-8,餐饮,早餐,现金,a\n2024-01-05 12:00:00,支出,-30,餐饮,午餐,现金,b\n', s);
  assert.strictEqual(s.transactions.length, 2);
  assert.strictEqual(catName(s, s.transactions[0]), '餐饮/早餐');
  assert.strictEqual(catName(s, s.transactions[1]), '餐饮/午餐');
  const cats = s.categories.filter(function (c) { return c.name === '餐饮/早餐'; });
  assert.strictEqual(cats.length, 1);
});
ok('导入：二级为空时只用一级', () => {
  const s = C.defaultState();
  C.importCSV('交易时间,交易类型,金额,一级分类,二级分类,账户,备注\n2024-01-05 08:00:00,支出,-8,购物,,现金,a\n', s);
  assert.strictEqual(catName(s, s.transactions[0]), '购物');
});
ok('导入：单元格内已有二级不再叠加', () => {
  const s = C.defaultState();
  C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-01-05 08:00:00,支出,-8,餐饮/早餐,现金,a\n', s);
  assert.strictEqual(catName(s, s.transactions[0]), '餐饮/早餐');
});
ok('同二级复用同一分类', () => {
  const s = C.defaultState();
  C.importCSV('交易时间,交易类型,金额,一级分类,二级分类,账户,备注\n2024-01-05 08:00:00,支出,-8,餐饮,早餐,现金,a\n2024-01-06 08:00:00,支出,-9,餐饮,早餐,现金,b\n', s);
  const cats = s.categories.filter(function (c) { return c.name === '餐饮/早餐'; });
  assert.strictEqual(cats.length, 1);
});
ok('daysBetween 跨月', () => assert.strictEqual(C.daysBetween('2024-01-01', '2024-03-01'), 60));
ok('daysBetween 同一天为 0', () => assert.strictEqual(C.daysBetween('2024-01-01', '2024-01-01'), 0));
ok('已记账天数 = 首笔到今天（含首日）', () => {
  const s = C.defaultState();
  C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-01-05 10:00:00,支出,-1,餐饮,现金,a\n2024-01-05 12:00:00,支出,-2,交通,现金,b\n2024-01-09 12:00:00,支出,-3,交通,现金,c\n', s);
  const r = C.recordStats(s);
  assert.strictEqual(r.has, true);
  assert.strictEqual(r.total, 3);
  assert.strictEqual(r.activeDays, 2);
  assert.strictEqual(r.firstDay, '2024-01-05');
  assert.strictEqual(r.lastDay, '2024-01-09');
  assert.strictEqual(r.days, C.daysBetween('2024-01-05', C.todayStr()) + 1);
});
ok('没有记录时 0 天', () => {
  const r = C.recordStats(C.defaultState());
  assert.strictEqual(r.has, false);
  assert.strictEqual(r.days, 0);
  assert.strictEqual(r.activeDays, 0);
});

console.log('--- 格式化 ---');
ok('fmtMoneyGroup', () => assert.strictEqual(C.fmtMoneyGroup(-1234567.891), '-1,234,567.89'));
ok('fmtMoney 舍入', () => assert.strictEqual(C.fmtMoney(0.005), '0.01'));

console.log('\n全部通过：' + pass + ' 项');
