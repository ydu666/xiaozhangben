/* 用本机 Node 直接跑： node tests/core.test.js */
const assert = require('assert');
const C = require('../app/src/main/assets/core.js');

let pass = 0;
function ok(name, fn) { fn(); pass++; console.log('  ok  ' + name); }

console.log('--- normalizeDateTime ---');
ok('标准格式', () => assert.strictEqual(C.normalizeDateTime('2024-01-02 03:04:05'), '2024-01-02 03:04:05'));
ok('斜杠+无秒', () => assert.strictEqual(C.normalizeDateTime('2024/1/2 3:04'), '2024-01-02 03:04:00'));
ok('ISO T 毫秒 Z', () => assert.strictEqual(C.normalizeDateTime('2024-01-02T03:04:05.123Z'), '2024-01-02 03:04:05'));
ok('带时区偏移', () => assert.strictEqual(C.normalizeDateTime('2024-01-02T03:04:05+08:00'), '2024-01-02 03:04:05'));
ok('中文年月日', () => assert.strictEqual(C.normalizeDateTime('2024年1月2日 03:04'), '2024-01-02 03:04:00'));
ok('只有日期', () => assert.strictEqual(C.normalizeDateTime('2024-01-02'), '2024-01-02 00:00:00'));
ok('空值', () => assert.strictEqual(C.normalizeDateTime(''), null));
ok('乱码', () => assert.strictEqual(C.normalizeDateTime('abc'), null));
ok('非法月份', () => assert.strictEqual(C.normalizeDateTime('2024-13-01'), null));

console.log('--- parseAmount ---');
ok('普通', () => assert.strictEqual(C.parseAmount('123.45'), 123.45));
ok('带符号与逗号', () => assert.strictEqual(C.parseAmount('¥ -1,234.50'), -1234.5));
ok('带元', () => assert.strictEqual(C.parseAmount('88元'), 88));
ok('空', () => assert.strictEqual(C.parseAmount(''), null));

console.log('--- shiftMonth ---');
ok('跨年回退', () => assert.strictEqual(C.shiftMonth('2024-01', -1), '2023-12'));
ok('跨年前进', () => assert.strictEqual(C.shiftMonth('2024-12', 1), '2025-01'));
ok('多月回退', () => assert.strictEqual(C.shiftMonth('2024-03', -14), '2023-01'));

console.log('--- 账目计算 ---');
const st = C.defaultState();
const acc = st.accounts[1];
st.settings.defaultAccountId = acc.id;
ok('初始余额 0', () => assert.strictEqual(C.accountBalance(st, acc.id), 0));

C.importCSV(
  '交易时间,交易类型,金额,分类,账户,备注\n' +
  '2024-01-05 10:00:00,支出,-30.50,餐饮,微信零钱,午饭\n' +
  '2024-01-06 09:00:00,收入,8000,工资,微信零钱,发薪\n' +
  '2024-01-07 12:00:00,支出,-19.90,交通,现金,打车\n',
  st
);
ok('导入 3 条', () => assert.strictEqual(st.transactions.length, 3));
ok('余额 7969.50（打车走现金，不影响微信）', () => assert.strictEqual(C.accountBalance(st, acc.id), 7969.5));

const s1 = C.monthSummary(st, '2024-01');
ok('月支出 50.40', () => assert.strictEqual(s1.expense, 50.4));
ok('月收入 8000', () => assert.strictEqual(s1.income, 8000));
ok('月结余 7949.60', () => assert.strictEqual(s1.net, 7949.6));
ok('笔数 3', () => assert.strictEqual(s1.count, 3));

const g = C.groupByDay(C.monthTransactions(st, '2024-01'));
ok('分组 3 天', () => assert.strictEqual(g.length, 3));

const ct = C.categoryTotals(st, '2024-01', 'expense');
ok('支出分类首位是餐饮 30.50', () => { assert.strictEqual(ct[0].name, '餐饮'); assert.strictEqual(ct[0].amount, 30.5); });

const tr = C.monthlyTrend(st, '2024-02', 3);
ok('趋势 3 个月且升序', () => {
  assert.deepStrictEqual(tr.map(x => x.month), ['2023-12', '2024-01', '2024-02']);
  assert.strictEqual(tr[1].expense, 50.4);
});

console.log('--- 转账 ---');
const st2 = C.defaultState();
const a1 = st2.accounts[0].id, a2 = st2.accounts[3].id;
st2.transactions.push({ id: 'x', type: 'transfer', time: '2024-02-01 00:00:00', amount: 100, accountId: a1, toAccountId: a2, categoryId: null, note: '' });
ok('转出 -100', () => assert.strictEqual(C.accountBalance(st2, a1), -100));
ok('转入 +100', () => assert.strictEqual(C.accountBalance(st2, a2), 100));
ok('转账不计入收支', () => assert.strictEqual(C.monthSummary(st2, '2024-02').expense, 0));

console.log('--- CSV 往返 ---');
const csv = C.transactionsToCSV(st);
const st3 = C.defaultState();
const res = C.importCSV(csv, st3);
ok('往返条数一致', () => assert.strictEqual(res.created.length, 3));
ok('往返无错误', () => assert.deepStrictEqual(res.errors, []));
ok('往返金额一致', () => {
  const sum = st3.transactions.reduce((s, t) => s + (t.type === 'expense' ? -t.amount : t.amount), 0);
  assert.strictEqual(Math.round(sum * 100) / 100, 7949.6);
});
ok('往返日期一致', () => {
  const t = st3.transactions.find(x => x.note === '午饭');
  assert.strictEqual(t.time, '2024-01-05 10:00:00');
});

console.log('--- CSV 解析边界 ---');
ok('引号内逗号与换行', () => {
  const rows = C.parseCSV('a,b\n"x,1","y\n2"\n');
  assert.deepStrictEqual(rows, [['a', 'b'], ['x,1', 'y\n2']]);
});
ok('转义双引号', () => {
  const rows = C.parseCSV('"a""b",c');
  assert.deepStrictEqual(rows, [['a"b', 'c']]);
});
ok('BOM 与 CRLF', () => {
  const rows = C.parseCSV('\uFEFFa,b\r\n1,2\r\n');
  assert.deepStrictEqual(rows, [['a', 'b'], ['1', '2']]);
});

console.log('--- 导入容错 ---');
const bad = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n不是日期,支出,10,餐饮,,x\n2024-03-01,支出,加哦,餐饮,,x\n2024-03-02,转账,50,,,\n', C.defaultState());
ok('坏行进 errors 不中断', () => {
  assert.strictEqual(bad.created.length, 0);
  assert.strictEqual(bad.errors.length, 3);
});
ok('缺表头报错', () => {
  const r = C.importCSV('123\n456\n', C.defaultState());
  assert.strictEqual(r.created.length, 0);
  assert.ok(/表头/.test(r.errors[0].reason));
});
ok('自动建分类', () => {
  const s = C.defaultState();
  const r = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-03-01 08:00:00,支出,-5,咖啡,,x\n', s);
  assert.strictEqual(r.created.length, 1);
  assert.ok(C.findByName(s.categories, '咖啡', 'expense'));
});
ok('自动建账户', () => {
  const s = C.defaultState();
  const r = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-03-01 08:00:00,支出,-5,餐饮,新银行卡,x\n', s);
  assert.strictEqual(r.created.length, 1);
  assert.ok(C.findByName(s.accounts, '新银行卡'));
});
ok('负数金额按支出', () => {
  const s = C.defaultState();
  const r = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-03-01,,-9.9,餐饮,,x\n', s);
  assert.strictEqual(r.created[0].type, 'expense');
  assert.strictEqual(r.created[0].amount, 9.9);
});
ok('正数金额无类型按收入', () => {
  const s = C.defaultState();
  const r = C.importCSV('交易时间,交易类型,金额,分类,账户,备注\n2024-03-01,,9.9,工资,,x\n', s);
  assert.strictEqual(r.created[0].type, 'income');
});

console.log('--- 格式化 ---');
ok('fmtMoneyGroup', () => assert.strictEqual(C.fmtMoneyGroup(-1234567.891), '-1,234,567.89'));
ok('fmtMoney 舍入', () => assert.strictEqual(C.fmtMoney(0.005), '0.01'));

console.log('\n全部通过：' + pass + ' 项');
